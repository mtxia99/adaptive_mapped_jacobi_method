function u = D1nonlinear(u)
    u = (1 - 2 * u); % u = zeros(size(u));
end