function u = Nonlinear(u)
    % Allen-Cahn equation
    u = u .* (1 - u); % u = zeros(size(u));
end