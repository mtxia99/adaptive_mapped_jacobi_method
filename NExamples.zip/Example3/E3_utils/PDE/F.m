function Fval = F(x, y, t)
    Fval = Dt(x, y, t) + AD(x, y, t) + FD(x, y, t) + N(x, y, t); %;
end

function val = Dt(x, y, t)
    A = (x - t/2).^2 + (y - sqrt(3)*t/2).^2 + (t + 1).^2;
    val = 13*(t + 1)^12./A.^7 - 7*(t + 1)^13 *(2*(t + 1) - (x - t/2) - sqrt(3)*(y - sqrt(3)*t/2))./A.^8;
end

function val = AD(x, y, t)
    val = 7*(t + 1)^13 * ((t/2 - x) + (3*t/2 - sqrt(3)*y))./(2*t^2 - t*(x + sqrt(3)*y - 2) + x.^2 + y.^2 + 1).^8;
end

function val = N(x, y, t)
    val = (t + 1)^13./((t + 1)^2 + (x - t/2).^2 + (y - sqrt(3)*t/2).^2).^7;
    val = val .* (1 - val);
end

function val = FD(x, y, t)
    N = 30000;
    z = sqrt((x - t/2).^2 + (y - sqrt(3)*t/2).^2)/(t + 1);
    
    basis = ones(size(z)); coe = 1; val = ones(size(z));
    for n = 0 : N
        basis = basis .* (z.^2./(1 + z.^2));
        coe = coe * (7 + 1/2 + n) * (-1/2 + n)/(n + 1)^2;
        val = val + basis * coe;
    end
    const = pi/2 * (1/12 + 1) * (1/10 + 1) * (1/8 + 1) * (1/6 + 1) * (1/4 + 1) * (1/2 + 1)/(t + 1)^2;
    val = const * val./(1 + z.^2).^(7 + 1/2);
end