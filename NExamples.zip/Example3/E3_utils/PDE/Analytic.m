function val = Analytic(x, y, t)
    val = (t + 1)^13./((t + 1)^2 + (x - t/2).^2 + (y - sqrt(3)*t/2).^2).^7;
end