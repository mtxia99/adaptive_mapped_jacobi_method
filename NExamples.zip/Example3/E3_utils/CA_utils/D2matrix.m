function d2matrix = D2matrix(N, beta, Nx, Ny)
    NC = length(Nx);

    Dx = DF1mat(N, beta(1)); Dy = DF1mat(N, beta(2));
    [Vx, Ex] = eig(Dx, 'vector'); [Vy, Ey] = eig(Dy, 'vector');
    
    E = zeros(N^2);
    for nx = 1 : N
        for ny = 1 : N
            E(nx + N * (ny - 1), nx + N * (ny - 1)) = sqrt(Ex(nx) + Ey(ny));
        end
    end
    
    V = zeros(N^2);
    for nx = 1 : N
        for ny = 1 : N
            for mx = 1 : N
                for my = 1 : N
                    V(mx + N * (my - 1), nx + N * (ny - 1)) = Vx(mx, nx) * Vy(my, ny);
                end
            end
        end
    end
    DF2mat = V * E * V';
    
    Dmat = zeros(NC);
    for ell = 1 : NC
        for nu = 1 : NC
            Dmat(ell, nu) = DF2mat(1 + Nx(ell) + N * Ny(ell), 1 + Nx(nu) +  N * Ny(nu));
        end
    end
    d2matrix = Dmat + Amat(N, beta, Nx, Ny); 
end

function a2mat = Amat(N, beta, Nx, Ny)
    [col_x, wx] = Quad(N, 0, beta(1));
    [col_y, wy] = Quad(N, 0, beta(2));
    
    Jx = zeros(N, N); Dx = zeros(N, N);
    Jy = zeros(N, N); Dy = zeros(N, N);
    for ell = 1 : N
        Jx(:, ell) = Basis(col_x, ell - 1, 0, beta(1)) .* wx;
        Jy(:, ell) = Basis(col_y, ell - 1, 0, beta(2)) .* wy;
        Dx(:, ell) = D1Basis(col_x, ell - 1, 0, beta(1));
        Dy(:, ell) = D1Basis(col_y, ell - 1, 0, beta(2));
    end
    
    Ax = -1/2 * Dx' * Jx; Ay = -sqrt(3)/2 * Dy' * Jy;
    NC = length(Nx);
    a2mat = zeros(NC, NC);
    for ell = 1 : NC
        for nu = 1 : NC
            if Ny(ell) == Ny(nu)
                a2mat(ell, nu) = a2mat(ell, nu) + Ax(Nx(ell) + 1, Nx(nu) + 1);
            end
            if Nx(ell) == Nx(nu)
                a2mat(ell, nu) = a2mat(ell, nu) + Ay(Ny(ell) + 1, Ny(nu) + 1);
            end
        end
    end
end

function A = DF1mat(N, beta)
    gamma = pi/2 * ones(N, 1); gamma(1) = pi;
    A = zeros(N);
    for m = 0 : N - 1
        for n = 0 : N - 1
            if m == n
                res = 6 * m^2 + 2 + 2 * Delta(m, 0) - Delta(m, 2);
                A(m + 1, n + 1) = res * beta^2 * pi/32/sqrt(gamma(m + 1)*gamma(n + 1));
            elseif m == n + 2
                res = -4 * (m^2 - 2*m + 1) - 4 * Delta(m, 2);
                A(m + 1, n + 1) = res * beta^2 * pi/32/sqrt(gamma(m + 1)*gamma(n + 1));
            elseif m == n - 2
                res = -4 * (m^2 + 2*m + 1) - 4 * Delta(m, 0);
                A(m + 1, n + 1) = res * beta^2 * pi/32/sqrt(gamma(m + 1)*gamma(n + 1));
            elseif m == n + 4
                res = m^2 - 4*m + 3 + 3 * Delta(m, 4);
                A(m + 1, n + 1) = res * beta^2 * pi/32/sqrt(gamma(m + 1)*gamma(n + 1));
            elseif m == n - 4
                res = m^2 + 4*m + 3 + 3 * Delta(m, 0);
                A(m + 1, n + 1) = res * beta^2 * pi/32/sqrt(gamma(m + 1)*gamma(n + 1));
            end
        end
    end
end

function val = Delta(m, n)
    if m == n
        val = 1;
    else
        val = 0;
    end
end