function val = Inverse(X, Y, coe, alpha, beta, Nx, Ny)
    val = zeros(size(X));
    for ell = 1 : length(Nx)
        val = val + coe(ell) * Basis(X, Nx(ell), alpha(1), beta(1)) .* Basis(Y, Ny(ell), alpha(2), beta(2));
    end
end