function Resplot(u, v)
    figure
    dis = log(abs(u-v) + 1e-7)/log(10);
    imagesc(dis, [-7, -2])
    c = colorbar;
    axis square
    colormap(othercolor('BuDRd_12'))
end