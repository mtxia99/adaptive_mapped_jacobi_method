function Heatmap(u)
    figure
    imagesc(u, [0, 3])
    colorbar
    axis square
    colormap(othercolor('BuDRd_12'))
    set(gca, 'Colorscale', 'log')
end