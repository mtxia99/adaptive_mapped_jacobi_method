function exte = Exterior_error_indicator(coe, N, beta, Nx, Ny, direction)
    Iup = N + 1 - floor(N/3); Idown = floor(N/3);
    [col_x, ~] = Quad(N, 0, beta(1));
    [col_y, ~] = Quad(N, 0, beta(2));
    if nargin == 5
        position = [col_x(Iup), col_x(Idown), col_y(Iup), col_y(Idown)];
        exte = [ExR(coe, N, beta(1), Nx, Ny, position(1));
                ExL(coe, N, beta(1), Nx, Ny, position(2));
                EyR(coe, N, beta(2), Nx, Ny, position(3));
                EyL(coe, N, beta(2), Nx, Ny, position(4))];
    elseif strcmp(direction, 'xR')
        position = col_x(Iup);
        exte = ExR(coe, N, beta(1), Nx, Ny, position);
    elseif strcmp(direction, 'yR')
        position = col_y(Iup);
        exte = EyR(coe, N, beta(2), Nx, Ny, position);
    elseif strcmp(direction, 'xL')
        position = col_x(Idown);
        exte = ExL(coe, N, beta(1), Nx, Ny, position);
    elseif strcmp(direction, 'yL')
        position = col_y(Idown);
        exte = EyL(coe, N, beta(2), Nx, Ny, position);
    end
end

function val = ExR(coe, N, beta, Nx, Ny, position)
    total = 0; res = 0;
    dmat = DFmat(N, beta);
    smat = semiR(N, beta, position);
    
    NC = length(Nx);
    for m = 1 : NC
        for n = 1 : NC
            if Ny(m) == Ny(n)
                total = total + coe(m) * coe(n) * dmat(Nx(m) + 1, Nx(n) + 1);
                res = res + coe(m) * coe(n) * smat(Nx(m) + 1, Nx(n) + 1);
            end
        end
    end
    val = sqrt(res/total);
end

function val = EyR(coe, N, beta, Nx, Ny, position)
    total = 0; res = 0;
    dmat = DFmat(N, beta);
    smat = semiR(N, beta, position);
    
    NC = length(Nx);
    for m = 1 : NC
        for n = 1 : NC
            if Nx(m) == Nx(n)
                total = total + coe(m) * coe(n) * dmat(Ny(m) + 1, Ny(n) + 1);
                res = res + coe(m) * coe(n) * smat(Ny(m) + 1, Ny(n) + 1);
            end
        end
    end
    val = sqrt(res/total);
end

function val = ExL(coe, N, beta, Nx, Ny, position)
    total = 0; res = 0;
    dmat = DFmat(N, beta);
    smat = semiL(N, beta, position);
    
    NC = length(Nx);
    for m = 1 : NC
        for n = 1 : NC
            if Ny(m) == Ny(n)
                total = total + coe(m) * coe(n) * dmat(Nx(m) + 1, Nx(n) + 1);
                res = res + coe(m) * coe(n) * smat(Nx(m) + 1, Nx(n) + 1);
            end
        end
    end
    val = sqrt(res/total);
end

function val = EyL(coe, N, beta, Nx, Ny, position)
    total = 0; res = 0;
    dmat = DFmat(N, beta);
    smat = semiL(N, beta, position);
    
    NC = length(Nx);
    for m = 1 : NC
        for n = 1 : NC
            if Nx(m) == Nx(n)
                total = total + coe(m) * coe(n) * dmat(Ny(m) + 1, Ny(n) + 1);
                res = res + coe(m) * coe(n) * smat(Ny(m) + 1, Ny(n) + 1);
            end
        end
    end
    val = sqrt(res/total);
end

function sdmat = semiR(N, beta, position)
    [col, w] = MCSG_semi_algebraic(N, position, 1);
    Dvec = zeros(N);
    for ell = 0 : N - 1
        Dvec(:, ell + 1) = D1Basis(col, ell, 0, beta);
    end
    sdmat = Dvec' * diag(w) * Dvec;
end

function sdmat = semiL(N, beta, position)
    [col, w] = MCSG_semi_algebraic(N, 0, 1);
    col = position - col;
    Dvec = zeros(N);
    for ell = 0 : N - 1
        Dvec(:, ell + 1) = D1Basis(col, ell, 0, beta);
    end
    sdmat = Dvec' * diag(w) * Dvec;
end

function A = DFmat(N, beta)
    gamma = pi/2 * ones(N, 1); gamma(1) = pi;
    A = zeros(N);
    for m = 0 : N - 1
        for n = 0 : N - 1
            if m == n
                res = 6 * m^2 + 2 + 2 * Delta(m, 0) - Delta(m, 2);
                A(m + 1, n + 1) = res * beta^2 * pi/32/sqrt(gamma(m + 1)*gamma(n + 1));
            elseif m == n + 2
                res = -4 * (m^2 - 2*m + 1) - 4 * Delta(m, 2);
                A(m + 1, n + 1) = res * beta^2 * pi/32/sqrt(gamma(m + 1)*gamma(n + 1));
            elseif m == n - 2
                res = -4 * (m^2 + 2*m + 1) - 4 * Delta(m, 0);
                A(m + 1, n + 1) = res * beta^2 * pi/32/sqrt(gamma(m + 1)*gamma(n + 1));
            elseif m == n + 4
                res = m^2 - 4*m + 3 + 3 * Delta(m, 4);
                A(m + 1, n + 1) = res * beta^2 * pi/32/sqrt(gamma(m + 1)*gamma(n + 1));
            elseif m == n - 4
                res = m^2 + 4*m + 3 + 3 * Delta(m, 0);
                A(m + 1, n + 1) = res * beta^2 * pi/32/sqrt(gamma(m + 1)*gamma(n + 1));
            end
        end
    end
end

function val = Delta(m, n)
    if m == n
        val = 1;
    else
        val = 0;
    end
end

function [col, w] = MCSG_semi_algebraic(N, alpha, beta)
    temp = zeros(1, N);
    for m = 0 : N - 1
        temp(m + 1) = - cos((2*m + 1)*pi/(2*N));
    end
    col = 1/beta * (1 + temp)./(1 - temp);
    w = 2 * pi/N/beta ./(1 - temp).^2 .* sqrt(1 - temp.^2);
    col = col + alpha;
end