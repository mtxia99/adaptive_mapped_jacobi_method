function freq = Frequency_indicator(coe, N, gamma, Nx, Ny, direction)
    if nargin == 5
        freq = [Fx(coe, N, gamma, Nx, Ny);
                Fy(coe, N, gamma, Nx, Ny)];
    elseif strcmp(direction, 'y')
        freq = Fy(coe, N, gamma, Nx, Ny);
    elseif strcmp(direction, 'x')
        freq = Fx(coe, N, gamma, Nx, Ny);
    end
end

function fx = Fx(coe, N, gamma, Nx, Ny)
    total = sum(coe.^2); res = 0;
    NC = length(Nx);
    for n = 1 : NC
        if max(1, 3/2 * Nx(n)) * max(1, Ny(n)) * max(3/2 * Nx(n), Ny(n))^gamma > N^(1 + gamma)
            res = res + coe(n)^2;
        end
    end
    fx = sqrt(res/total);
end

function fy = Fy(coe, N, gamma, Nx, Ny)
    total = sum(coe.^2); res = 0;
    NC = length(Ny);
    for n = 1 : NC
        if max(1, Nx(n)) * max(1, 3/2 * Ny(n)) * max(Nx(n), 3/2 * Ny(n))^gamma > N^(1 + gamma)
            res = res + coe(n)^2;
        end
    end
    fy = sqrt(res/total);
end
