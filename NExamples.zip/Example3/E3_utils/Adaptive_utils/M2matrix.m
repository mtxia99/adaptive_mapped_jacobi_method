function m2matrix = M2matrix(N, d, beta, Nx, Ny)
    [col_x, wx] = Quad(N, d(1), beta(1));
    [col_y, wy] = Quad(N, d(2), beta(2));
    
    [X, Y] = ndgrid(col_x, col_y);
    [wx, wy] = ndgrid(wx, wy);
    w = wx .* wy;
    
    NC = length(Nx);
    Proj = zeros(NC, N^2); Inv = zeros(N^2, NC);
    for ell = 1 : NC
        nx = Nx(ell); ny = Ny(ell);
        B2vec = Basis(X, nx, d(1), beta(1)) .* Basis(Y, ny, d(2), beta(2));
        P2vec = Vec(B2vec .* w); Proj(ell, :) = P2vec;
        
        B2vec = Basis(X, nx, 0, beta(1)) .* Basis(Y, ny, 0, beta(2));
        I2vec = Vec(B2vec); Inv(:, ell) = I2vec';
    end
    m2matrix = Proj * Inv;
end