function freq = Frequency_indicator_compare(coe, N, gamma, Nx, Ny, direction)
    if nargin == 5
        freq = [Fx(coe, N, gamma, Nx, Ny);
                Fy(coe, N, gamma, Nx, Ny)];
    elseif strcmp(direction, 'y')
        freq = Fy(coe, N, gamma, Nx, Ny);
    elseif strcmp(direction, 'x')
        freq = Fx(coe, N, gamma, Nx, Ny);
    end
end

function fx = Fx(coe, N, gamma, Nx, Ny)
    total = sum(coe.^2); res = 0;
    NC = length(Nx);
    for n = 1 : NC
        if Nx(n) > floor((2 * N + 2)/3)
            res = res + coe(n)^2;
        end
    end
    fx = sqrt(res/total);
end

function fy = Fy(coe, N, gamma, Nx, Ny)
    total = sum(coe.^2); res = 0;
    NC = length(Ny);
    for n = 1 : NC
        if Ny(n) > floor((2 * N + 2)/3)
            res = res + coe(n)^2;
        end
    end
    fy = sqrt(res/total);
end
