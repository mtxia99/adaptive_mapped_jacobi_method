function [Nx, Ny] = Hyperbolic(N, gamma)
    [X, Y] = ndgrid(0:N-1, 0:N-1);
    Nx = zeros(1, N^2); Ny = zeros(1, N^2);
    
    rec = 0;
    for ell = 1 : N
        for nu = 1 : N
            if max(1, X(ell, nu)) * max(1, Y(ell, nu)) * max(X(ell, nu), Y(ell, nu))^gamma <= N^(1 + gamma)
                rec = rec + 1;
                Nx(rec) = ell - 1;
                Ny(rec) = nu - 1;
            end
        end
    end
    
    Nx = Nx(1 : rec); Ny = Ny(1 : rec);
end