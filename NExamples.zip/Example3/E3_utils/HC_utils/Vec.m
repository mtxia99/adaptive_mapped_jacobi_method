function v = Vec(u)
    [M, N] = size(u);
    v = zeros(M * N, 1);
    for ell = 1 : M
        for nu = 1 : N
            v(ell + M * (nu - 1)) = u(ell, nu);
        end
    end
end