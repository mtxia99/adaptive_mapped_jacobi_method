clear;
addpath(genpath('E3_utils'))
% spatiotemporal parameters
T = 3; dt = 0.1;
time = 0 : dt : T;
KT = length(time);

% spectral method parameters
alpha = zeros(2, KT);
beta = 0.9 * ones(2, KT);
N = 45 * ones(KT); gamma = 5;
[Nx, Ny] = Hyperbolic(N(1), gamma);

% initialization
[col_x, wx] = Quad(N(1), alpha(1, 1), beta(1, 1));
[col_y, wy] = Quad(N(1), alpha(2, 1), beta(2, 1));
[X, Y] = ndgrid(col_x, col_y);
[wx, wy] = ndgrid(wx, wy); w = wx .* wy;
[Proj, Inv] = P2matrix(N(1), alpha(:, 1), beta(:, 1), Nx, Ny);

u = Analytic(X, Y, 0);
uvec = Vec(u);
coe = Proj * uvec;

% Recorders
Coe = zeros(length(Nx), KT);
Coe(:, 1) = coe;
Error = zeros(1, KT - 1);

% adaptive recorders
freq = Frequency_indicator(coe, N(1), gamma, Nx, Ny);
exte = Exterior_error_indicator(coe, N(1), beta(:, 1), Nx, Ny);  %xR, yR, xL, yL
Frequency_res = freq * ones(1, KT);
Exterior_res = exte * ones(1, KT);

frequency_recorder = Frequency_res;
exterior_recorder = Exterior_res;

for ell = 1 : KT - 1
    % initialize
    [col_x, wx] = Quad(N(ell), alpha(1, ell), beta(1, ell));
    [col_y, wy] = Quad(N(ell), alpha(2, ell), beta(2, ell));
    [X, Y] = ndgrid(col_x, col_y);
    [wx, wy] = ndgrid(wx, wy); w = wx .* wy;
    [Proj, Inv] = P2matrix(N(ell), alpha(:, ell), beta(:, ell), Nx, Ny);

    d2matrix = D2matrix(N(ell), beta(:, ell), Nx, Ny);
    
    % RK method
    stage = time(ell) + dt * [0.069432, 0.33001, 0.66999, 0.93057];
    Fmat = zeros(N(ell)^2, 4);
    for s = 1 : 4
        Fmat(:, s) = Vec(F(X, Y, stage(s)));
    end
    Fmat = Proj * Fmat;
    
    coe = RK_solver(coe, dt, Fmat, d2matrix, Proj, Inv);
    Coe(:, ell + 1) = coe;
    
    % Record error
    uinv = Inverse(X, Y, coe, alpha(:, ell), beta(:, ell), Nx, Ny);
    ref = Analytic(X, Y, time(ell + 1));
    error = sqrt(sum(sum((ref - uinv).^2 .* w)))/sqrt(sum(sum(ref.^2 .* w)))
    Error(ell) = error;
    
    % adaptives
    Xmax = 0.06; Ymax = 0.09; d = 0.01; mu = 1.0005;
    betamin = 0; q = 0.99;
    % moving
    exte = Exterior_error_indicator(coe, N(ell), beta(:, ell), Nx, Ny);
    
    xR = 0; xL = 0;
    tempM = coe;
    m2matrix = M2matrix(N(ell), [d; 0], beta(:, ell), Nx, Ny);
    while exte(1) > Exterior_res(1, ell) * mu
        xR = xR + d;
        tempM = m2matrix * tempM;
        if abs(xR) >= Xmax - 1e-3;
            break
        end
        exte(1) = Exterior_error_indicator(tempM, N(ell), beta(:, ell), Nx, Ny, 'xR');
    end
    
    tempM = coe;
    m2matrix = M2matrix(N(ell), [-d; 0], beta(:, ell), Nx, Ny);
    while exte(2) > Exterior_res(2, ell) * mu
        xL = xL - d;
        tempM = m2matrix * tempM;
        if abs(xL) >= Xmax - 1e-3;
            break
        end
        exte(2) = Exterior_error_indicator(tempM, N(ell), beta(:, ell), Nx, Ny, 'xL');
    end
    
    yR = 0; yL = 0;
    tempM = coe;
    m2matrix = M2matrix(N(ell), [0; d], beta(:, ell), Nx, Ny);
    while exte(3) > Exterior_res(3, ell) * mu
        yR = yR + d;
        tempM = m2matrix * tempM;
        if abs(yR) >= Ymax - 1e-3;
            break
        end
        exte(3) = Exterior_error_indicator(tempM, N(ell), beta(:, ell), Nx, Ny, 'yR');
    end
    
    tempM = coe;
    m2matrix = M2matrix(N(ell), [0; -d], beta(:, ell), Nx, Ny);
    while exte(4) > Exterior_res(4, ell) * mu
        yL = yL - d;
        tempM = m2matrix * tempM;
        if abs(yL) >= Ymax - 1e-3;
            break
        end
        exte(4) = Exterior_error_indicator(tempM, N(ell), beta(:, ell), Nx, Ny, 'yL');
    end
    
    % moving update
    displace = [xR + xL; yR + yL]
    m2matrix = M2matrix(N(ell), displace, beta(:, ell), Nx, Ny);
    coe = m2matrix * coe;

    exte = Exterior_error_indicator(coe, N(ell), beta(:, ell), Nx, Ny);
    Exterior_res(:, ell + 1) = exte;
    
    alpha(:, ell + 1) = alpha(:, ell) + displace; 
    
    % scaling
    freq = Frequency_indicator(coe, N(ell), gamma, Nx, Ny);
    
    sx = 1;
    tempS = coe;
    s2matrix = S2matrix(N(ell), [q; 1], Nx, Ny);
    if freq(1) > Frequency_res(1, ell)/q
        sx = sx * q;
        tempS = s2matrix * tempS;
        freq_update = Frequency_indicator(tempS, N(ell), gamma, Nx, Ny, 'x');
        while freq_update <= freq(1)
            freq(1) = freq_update;
            sx = sx * q;
            tempS = s2matrix * tempS;
            freq_update = Frequency_indicator(tempS, N(ell), gamma, Nx, Ny, 'x');
        end
        sx = sx/q;
    end
    
    sy = 1;
    tempS = coe;
    s2matrix = S2matrix(N(ell), [1; q], Nx, Ny);
    if freq(2) > Frequency_res(2, ell)/q
        sy = sy * q;
        tempS = s2matrix * tempS;
        freq_update = Frequency_indicator(tempS, N(ell), gamma, Nx, Ny, 'y');
        while freq_update <= freq(2)
            freq(2) = freq_update;
            sy = sy * q;
            tempS = s2matrix * tempS;
            freq_update = Frequency_indicator(tempS, N(ell), gamma, Nx, Ny, 'y');
        end
        sy = sy/q;
    end
    
    % scaling update
    Frequency_res(:, ell + 1) = freq;
    factor = [sx; sy]
    s2matrix = S2matrix(N(ell), factor, Nx, Ny);
    coe = s2matrix * coe;
    
    beta(:, ell + 1) = beta(:, ell) .* factor; 
    
    freq = Frequency_indicator(coe, N(ell), gamma, Nx, Ny);
    exte = Exterior_error_indicator(coe, N(ell), beta(:, ell), Nx, Ny);

    exterior_recorder(:, ell) = exte;
    frequency_recorder(:, ell) = freq;
end
clearvars -except alpha beta N Error frequency_recorder exterior_recorder
rmpath(genpath('E3_utils'))