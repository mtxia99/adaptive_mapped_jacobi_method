function val = D1Basis(x, N, alpha, beta)
    x = tanh((x - alpha) * beta);
    val = N^2/(2*N + 1) * Legendre(x, N - 1) - (N + 1)^2/(2*N + 1) * Legendre(x, N + 1);
    gamma = 2/(2*N + 1);
    val = beta * sqrt(beta/gamma) * val .* sqrt(1 - x.^2);
end
