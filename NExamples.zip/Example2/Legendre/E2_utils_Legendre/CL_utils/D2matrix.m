function A = D2matrix(N, beta)
    A = zeros(N);
    for m = 0 : N - 1
        for n = 0 : N - 1
            if m == n
                res = (2 * m + 1)/(2 * m - 1) * m^4/(2*m + 1)^2 + (2 * m + 1)/(2 * m + 3) * (m + 1)^4/(2*m + 1)^2;
                A(m + 1, n + 1) = res * beta^2;
            elseif m == n - 2
                res = sqrt((2*m + 1) * (2*m + 5))/(2*m + 3) * (m + 1)^2 * (m + 2)^2/(2*m + 1)/(2*m + 5);
                A(m + 1, n + 1) = -res * beta^2;
            elseif m == n + 2
                res = sqrt((2*m + 1) * (2*m - 3))/(2*m - 1) * m^2 * (m - 1)^2/(2*m + 1)/(2*m - 3);
                A(m + 1, n + 1) = -res * beta^2;
            end
        end
    end
end