function [col, w] = Quad(N, alpha, beta)
    A = zeros(N);
    for n = 0 : N - 1
        if n == 0
            A(n + 1, n + 1) = 0;
            A(n + 1, n + 2) = (n + 1)/sqrt(4*(n + 1)^2 - 1);
        elseif n == N - 1
            A(n + 1, n + 1) = 0;
            A(n + 1, n) = n/sqrt(4*n^2 - 1);
        else
            A(n + 1, n + 1) = 0;
            A(n + 1, n) = n/sqrt(4*n^2 - 1);
            A(n + 1, n + 2) = (n + 1)/sqrt(4*(n + 1)^2 - 1);
        end
    end
    col = sort(eig(A))';
    w = 2 * (2*N + 1)^2/N^2/(N + 1)^2 * (1 - col.^2)./(Legendre(col, N - 1) - Legendre(col, N + 1)).^2;
    
    col = 1/2/beta * log((1 + col)./(1 - col));
    w = 1/beta * w .* cosh(col * beta).^2;
    col = col + alpha;
end