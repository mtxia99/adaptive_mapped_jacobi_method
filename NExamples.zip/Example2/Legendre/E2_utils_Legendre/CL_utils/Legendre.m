function y = Legendre(x, n)
    if n < 0
        y = zeros(size(x));
    elseif n == 0
        y = ones(size(x));
    elseif n == 1
        y = x;
    else
        y1 = ones(size(x));
        y2 = x;
        for i = 2 : n
            y3 = (2 - 1/i) * x .* y2 - (1 - 1/i) * y1;
            y1 = y2;
            y2 = y3;
        end
        y = y2;
    end
end