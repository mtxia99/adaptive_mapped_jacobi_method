function val = Basis(x, N, alpha, beta)
    x = tanh((x - alpha) * beta);
    val = Legendre(x, N);
    gamma = 2/(2*N + 1);
    val = sqrt(beta/gamma) * val .* sqrt(1 - x.^2);
end