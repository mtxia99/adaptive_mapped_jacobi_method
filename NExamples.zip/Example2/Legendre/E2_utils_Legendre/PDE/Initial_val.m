function y = Initial_val(x)
    y = (exp(-(x - 4).^2/2) + exp(-(x + 4).^2/2))/2/sqrt(2*pi);
end