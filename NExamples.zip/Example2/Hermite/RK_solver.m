function u = RK_solver(u0, tau, d2matrix, Dproj, Inv, sinv)
    % RK method of 4th order
    [A, b] = RK_coe;
    
    % stage variables
    K = cat(2, u0, u0, u0, u0);
    [N, ~] = size(K);
    
    % iteration initialize
    coVec = K/A;
    alpha = 0.5; w = 0;
    
    B = inv(alpha * eye(4) + inv(A));
    
    itermax = 500;
    for iter = 1 : itermax
        f = alpha * K - K/A + coVec;
        K2 = Newton_solver(f, tau, alpha, d2matrix, Dproj, Inv, sinv);
        K = (K/A - (1 - w) * K * alpha + (2 - w) * alpha * K2) * B;
        
        val = K/A + tau * d2matrix * K + tau * Nonlinear(K, Dproj, Inv, sinv) - coVec;
%         converge = sqrt(sum(sum(val.^2))/N)
        if sqrt(sum(sum(val.^2))/N) <= 1e-12
            break
        end
    end
    u = u0 - tau * (d2matrix * K + Nonlinear(K, Dproj, Inv, sinv)) * b;
end

function x = Newton_solver(f, tau, alpha, d2matrix, Dproj, Inv, sinv)
    x = f;
    [N, ~] = size(x);
    
    val = alpha * x + tau * d2matrix * x + tau * Nonlinear(x, Dproj, Inv, sinv) - f;
    
    itermax = 500;
    for iter = 1 : itermax
        grad = zeros(size(x));
        for ell = 1 : 4
            dval = alpha * eye(N) + tau * d2matrix + tau * D1nonlinear(x(:, ell), Dproj, Inv, sinv);
            grad(:, ell) = dval\val(:, ell);
        end
        x = x - grad;
        val = alpha * x + tau * d2matrix * x + tau * Nonlinear(x, Dproj, Inv, sinv) - f;
        
        if sqrt(sum(sum(val.^2))/N) <= 1e-12
            break
        end
    end
end

function [A, b] = RK_coe(~)
    A = [0.086964, -0.026604, 0.012627, -0.0035551;
        0.18812, 0.16304, -0.02788, 0.0067355;
        0.16719, 0.35395, 0.16304, -0.014191;
        0.17748, 0.31345, 0.35268, 0.086964];
    A = A';
    
    b = [0.17393; 0.32607; 0.32607; 0.17393];
end