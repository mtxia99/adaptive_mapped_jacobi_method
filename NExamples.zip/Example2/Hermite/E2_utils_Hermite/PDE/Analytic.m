function val = Analytic(x, t)
    val = 1/2 * 1./cosh(x - 2 * t).^2;
end