function Fval = F(x, t)
    Fval = 0;
end