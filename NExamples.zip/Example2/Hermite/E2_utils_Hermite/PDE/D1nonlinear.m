function A = D1nonlinear(u, Dproj, Inv, sinv)
    % Quadratic nonlinear
%     sinv = Sinv(N, alpha, beta);
    Uint = 2 * sinv * u - 1;
    Aint = Dproj .* diag(Uint) * Inv;
    
    U = Inv * u;
    A = 2 * Dproj .* diag(U) * sinv;
    
    A = -(A + Aint);
end