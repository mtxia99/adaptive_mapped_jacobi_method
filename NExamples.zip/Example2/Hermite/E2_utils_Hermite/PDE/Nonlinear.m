function u = Nonlinear(u, Dproj, Inv, sinv)
    % Quadratic nonlinear
    Uint = 2 * sinv * u - 1;
    U = Inv * u;
    u = -Dproj * (Uint .* U);
end