function Dproj = D1matrix(N, alpha, beta)
    [col, w] = Quad(N, alpha, beta);
    Dproj = zeros(N, N);
    for ell = 0 : N - 1
        D1vec = D1Basis(col, ell, alpha, beta);
        Dproj(ell + 1, :) = D1vec .* w;
    end
end