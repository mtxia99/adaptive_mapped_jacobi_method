function sinv = Sinv(N, alpha, beta)
    [col, ~] = Quad(N, alpha, beta);
    [Scol, Sw] = semi_Quad(3 * 1024, 0, beta);
    sinv = zeros(N, N);
    for ell = 0 : N - 1
        for nu = 1 : N
            temp_col = Scol + col(nu);
            val = Basis(temp_col, ell, alpha, beta) .* Sw;
            sinv(nu, ell + 1) = sum(val);
        end
    end
end