function [col, w] = semi_Quad(N, alpha, beta)
    temp = zeros(1, N);
    for m = 0 : N - 1
        temp(m + 1) = - cos((2*m + 1)*pi/(2*N));
    end
    col = 1/2/beta * log((3 + temp)./(1 - temp));
    w = 2 * pi/N/beta * (1 + temp).^(1/2) .* (1 - temp).^(-1/2) ./ (3 + temp);
    col = col + alpha;
end