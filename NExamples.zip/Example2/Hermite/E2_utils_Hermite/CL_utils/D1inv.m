function Dproj = D1inv(N, alpha, beta)
    [col, ~] = Quad(N, alpha, beta);
    Dproj = zeros(N, N);
    for ell = 0 : N - 1
        D1vec = D1Basis(col, ell, alpha, beta);
        Dproj(ell + 1, :) = D1vec;
    end
end