function A = D2matrix(N, beta)
    A = zeros(N);
    for m = 0 : N - 1
        for n = 0 : N - 1
            if m == n
                A(m + 1, n + 1) = beta^2/2 * (2 * m + 1);
            elseif m == n - 2
                A(m + 1, n + 1) = -beta^2/2 * sqrt((m + 1)*(m + 2));
            elseif m == n + 2
                A(m + 1, n + 1) = -beta^2/2 * sqrt(m*(m - 1));
            end
        end
    end
end