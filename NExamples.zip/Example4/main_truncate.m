clear;
addpath(genpath('E4_utils'))

% spatiotemporal parameters
T = 1; dt = 0.1;
time = 0 : dt : T;
KT = length(time);

% spectral method parameters
alpha = zeros(3, KT);
beta = 0.38 * ones(3, KT);
beta(2, :) = 0.4;
beta(3, :) = 0.3;
N = 25 * ones(1, KT); gamma = 10;
[Nx, Ny, Nz] = Hyperbolic(N(1), gamma);

% initialization
[col_x, wx] = Quad(N(1), alpha(1, 1), beta(1, 1));
[col_y, wy] = Quad(N(1), alpha(2, 1), beta(2, 1));
[col_z, wz] = Quad(N(1), alpha(3, 1), beta(3, 1));
[X, Y, Z] = ndgrid(col_x, col_y, col_z);
[wx, wy, wz] = ndgrid(wx, wy, wz); w = wx .* wy .* wz;
[Proj, ~] = P2matrix(N(1), alpha(:, 1), beta(:, 1), Nx, Ny, Nz);

u = Analytic(X, Y, Z, 0);
uvec = Vec(u);
coe = Proj * uvec;
clear u uvec

% Recorders
Error = zeros(1, KT - 1);

% adaptive recorders
freq = Frequency_indicator(coe, N(1), gamma, Nx, Ny, Nz)
exte = Exterior_error_indicator(coe, N(1), beta(:, 1), Nx, Ny, Nz)  %xR, yR, xL, yL
pfreq = P_indicator(coe, N(1), gamma, Nx, Ny, Nz);
Frequency_res = freq * ones(1, KT);
Exterior_res = exte * ones(1, KT);

P_res = pfreq;
frequency_recorder = Frequency_res;
exterior_recorder = Exterior_res;

Xmax = 0.05; Ymax = 0.05; Zmax = 0.05; d = 0.01; mu = 1.0005;
betamin = 0; q = 0.99;
eta = 1.2; eg = 1.1; Nmax = 5;

for ell = 1 : KT - 1
    % initialize
    [col_x, wx] = Quad(N(ell), alpha(1, ell), beta(1, ell));
    [col_y, wy] = Quad(N(ell), alpha(2, ell), beta(2, ell));
    [col_z, wz] = Quad(N(ell), alpha(3, ell), beta(3, ell));
    
    [X, Y, Z] = ndgrid(col_x, col_y, col_z);
    [wx, wy, wz] = ndgrid(wx, wy, wz); w = wx .* wy .* wz;
    [Proj, ~] = P2matrix(N(ell), alpha(:, ell), beta(:, ell), Nx, Ny, Nz);

    d2matrix = D2matrix(N(ell), beta(:, ell), Nx, Ny, Nz);
    
    % RK method
    stage = time(ell) + dt * [0.069432, 0.33001, 0.66999, 0.93057];
    Fmat = zeros(N(ell)^3, 4);
    for s = 1 : 4
        Fmat(:, s) = Vec(F(X, Y, Z, stage(s)));
    end
    Fmat = Proj * Fmat + d2matrix * Proj * cat(2, Vec(Analytic(X, Y, Z, stage(1))), Vec(Analytic(X, Y, Z, stage(2))), Vec(Analytic(X, Y, Z, stage(3))), Vec(Analytic(X, Y, Z, stage(4))));
    
    coe = RK_solver(coe, dt, Fmat, d2matrix);
    
    % Record error
    uinv = Inverse(X, Y, Z, coe, alpha(:, ell), beta(:, ell), Nx, Ny, Nz);
    ref = Analytic(X, Y, Z, time(ell + 1));
    error = sqrt(sum(sum(sum((ref - uinv).^2 .* w))))/sqrt(sum(sum(sum((ref).^2 .* w))))
    Error(ell) = error;
    
    % adaptives
    clear X Y Z w wx wy wz Proj uinv ref s2matrix d2matrix Fmat
    % moving
    exte = Exterior_error_indicator(coe, N(ell), beta(:, ell), Nx, Ny, Nz);
    
    xR = 0; xL = 0;
    if exte(1) > Exterior_res(1, ell) * mu
        tempM = coe;
        m2matrix = M2matrix(N(ell), [d; 0; 0], beta(:, ell), Nx, Ny, Nz);
    end
    while exte(1) > Exterior_res(1, ell) * mu
        xR = xR + d;
        tempM = m2matrix * tempM;
        if abs(xR) >= Xmax - 1e-3;
            break
        end
        exte(1) = Exterior_error_indicator(tempM, N(ell), beta(:, ell), Nx, Ny, Nz, 'xR');
    end
    
    tempM = coe;
    m2matrix = M2matrix(N(ell), [-d; 0; 0], beta(:, ell), Nx, Ny, Nz);
    while exte(2) > Exterior_res(2, ell) * mu
        xL = xL - d;
        tempM = m2matrix * tempM;
        if abs(xL) >= Xmax - 1e-3;
            break
        end
        exte(2) = Exterior_error_indicator(tempM, N(ell), beta(:, ell), Nx, Ny, Nz, 'xL');
    end
    
    yR = 0; yL = 0;
    if exte(3) > Exterior_res(3, ell) * mu
        tempM = coe;
        m2matrix = M2matrix(N(ell), [0; d; 0], beta(:, ell), Nx, Ny, Nz);
    end
    while exte(3) > Exterior_res(3, ell) * mu
        yR = yR + d;
        tempM = m2matrix * tempM;
        if abs(yR) >= Ymax - 1e-3;
            break
        end
        exte(3) = Exterior_error_indicator(tempM, N(ell), beta(:, ell), Nx, Ny, Nz, 'yR');
    end
    if exte(4) > Exterior_res(4, ell) * mu
        tempM = coe;
        m2matrix = M2matrix(N(ell), [0; -d; 0], beta(:, ell), Nx, Ny, Nz);
    end
    while exte(4) > Exterior_res(4, ell) * mu
        yL = yL - d;
        tempM = m2matrix * tempM;
        if abs(yL) >= Ymax - 1e-3;
            break
        end
        exte(4) = Exterior_error_indicator(tempM, N(ell), beta(:, ell), Nx, Ny, Nz, 'yL');
    end
    
    zR = 0; zL = 0;
    if exte(5) > Exterior_res(5, ell) * mu
        tempM = coe;
        m2matrix = M2matrix(N(ell), [0; 0; d], beta(:, ell), Nx, Ny, Nz);
    end
    while exte(5) > Exterior_res(5, ell) * mu
        zR = zR + d;
        tempM = m2matrix * tempM;
        if abs(zR) >= Zmax - 1e-3;
            break
        end
        exte(5) = Exterior_error_indicator(tempM, N(ell), beta(:, ell), Nx, Ny, Nz, 'zR');
    end
    if exte(6) > Exterior_res(6, ell) * mu
        tempM = coe;
        m2matrix = M2matrix(N(ell), [0; 0; -d], beta(:, ell), Nx, Ny, Nz);
    end
    while exte(6) > Exterior_res(6, ell) * mu
        zL = zL - d;
        tempM = m2matrix * tempM;
        if abs(zL) >= Zmax - 1e-3;
            break
        end
        exte(6) = Exterior_error_indicator(tempM, N(ell), beta(:, ell), Nx, Ny, Nz, 'zL');
    end
    
    % moving update
    displace = [xR + xL; yR + yL; zR + zL]
    m2matrix = M2matrix(N(ell), displace, beta(:, ell), Nx, Ny, Nz);
    coe = m2matrix * coe;

    exte = Exterior_error_indicator(coe, N(ell), beta(:, ell), Nx, Ny, Nz);
    Exterior_res(:, ell + 1) = exte;
    
    alpha(:, ell + 1) = alpha(:, ell) + displace; 
    
    % scaling
    freq = Frequency_indicator_compare(coe, N(ell), gamma, Nx, Ny, Nz);
    
    sx = 1;
    if freq(1) > Frequency_res(1, ell)/q
        s2matrix = S2matrix(N(ell), [q; 1; 1], Nx, Ny, Nz);
        tempsx = sx * q;
        tempS = s2matrix * coe;
        freq_update = Frequency_indicator_compare(tempS, N(ell), gamma, Nx, Ny, Nz, 'x');
        while freq_update <= freq(1)
            freq(1) = freq_update;
            sx = tempsx;
            tempsx = tempsx * q;
            tempS = s2matrix * tempS;
            freq_update = Frequency_indicator_compare(tempS, N(ell), gamma, Nx, Ny, Nz, 'x');
        end
    end
    
    sy = 1;
    if freq(2) > Frequency_res(2, ell)/q
        s2matrix = S2matrix(N(ell), [1; q; 1], Nx, Ny, Nz);
        tempsy = sy * q;
        tempS = s2matrix * coe;
        freq_update = Frequency_indicator_compare(tempS, N(ell), gamma, Nx, Ny, Nz, 'y');
        while freq_update <= freq(2)
            freq(2) = freq_update;
            sy = tempsy;
            tempsy = tempsy * q;
            tempS = s2matrix * tempS;
            freq_update = Frequency_indicator_compare(tempS, N(ell), gamma, Nx, Ny, Nz, 'y');
        end
    end
    
    sz = 1;
    if freq(3) > Frequency_res(3, ell)/q
        s2matrix = S2matrix(N(ell), [1; 1; q], Nx, Ny, Nz);
        tempsz = sz * q;
        tempS = s2matrix * coe;
        freq_update = Frequency_indicator_compare(tempS, N(ell), gamma, Nx, Ny, Nz, 'z');
        while freq_update <= freq(3)
            freq(3) = freq_update;
            sz = tempsz;
            tempsz = tempsz * q;
            tempS = s2matrix * tempS;
            freq_update = Frequency_indicator_compare(tempS, N(ell), gamma, Nx, Ny, Nz, 'z');
        end
    end
    
    % scaling update
    Frequency_res(:, ell + 1) = freq;
    factor = [sx; sy; sz]
    s2matrix = S2matrix(N(ell), factor, Nx, Ny, Nz);
    coe = s2matrix * coe;
    
    beta(:, ell + 1) = beta(:, ell) .* factor; 
    
    clear tempS
    % p-adaptive
    pfreq = P_indicator_compare(coe, N(ell), gamma, Nx, Ny, Nz);
    dN = 0;
    flag = 0;
    while pfreq > P_res * eta && dN < Nmax
        flag = 1;
        dN = dN + 1;
        p2matrix = pn2matrix(N(ell) + dN, gamma, alpha(:, ell + 1), beta(:, ell + 1), Nx, Ny, Nz);
        tempP = p2matrix * coe;
        [Nx_new, Ny_new, Nz_new] = Hyperbolic(N(ell) + dN, gamma);
        pfreq = P_indicator_compare(tempP, N(ell) + dN, gamma, Nx_new, Ny_new, Nz_new);
        clear p2matrix tempP Nx_new Ny_new Nz_new
    end
    if flag == 1
        eta = eta * eg;
        P_res = pfreq;
    end
    % order update
    N(ell + 1) = N(ell) + dN;
    N(ell + 1)
    p2matrix = pn2matrix(N(ell + 1), gamma, alpha(:, ell + 1), beta(:, ell + 1), Nx, Ny, Nz);
    coe = p2matrix * coe;
    clear p2matrix
    [Nx, Ny, Nz] = Hyperbolic(N(ell + 1), gamma);
    freq = Frequency_indicator(coe, N(ell + 1), gamma, Nx, Ny, Nz);
    frequency_recorder(:, ell) = freq;
end
clearvars -except alpha beta N Error frequency_recorder exterior_recorder
rmpath(genpath('E4_utils'))