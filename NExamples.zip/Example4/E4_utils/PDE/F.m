function Fval = F(x, y, z, t)
    Fval = Dt(x, y, z, t); %+ FD(x, y, z, t);
end

function val = Dt(x, y, z, t)
    val = exp(-(x.^2 + z.^2)/(6*t + 2) - y.^2/(6*t + 2));
    v1 = (6*(x.^2 + z.^2)/(6*t + 2).^2 + 6*y.^2/(6*t + 2).^2)/sqrt(3*t + 1)/(3*t + 1);
    v2 = -9/sqrt(3*t + 1)/(3*t + 1)^2/2;
%     v3 = -1/sqrt(2*t + 1)^3/(3*t + 1);
    val = val .* sin(x + 6*y/5 + z/2) .* (v1 + v2);
end

function val = FD(x, y, z, t)
    N = 500;
    Nell = 5;
    A = (x/sqrt(6*t + 2) - sqrt((3*t + 1)/2) * 1i).^2 + (y/sqrt(6*t + 2) - sqrt((3*t + 1)/2) * 1i).^2 + (z/sqrt(6*t + 2) - sqrt((3*t + 1)/2) * 1i).^2;
    const = 3.616022711580192856;
    
    basis = ones(size(A)); coe = 1;
    val = exp(-A);
    for n = 0 : N
        basis = basis .* ((-3/4 + n)/(n + 3/2)/(n + 1) * A).^(1/Nell);
        
        temp = ones(size(A));
        for ell = 1 : Nell
            temp = temp .* basis .* exp(-A/Nell);
        end
        val = val + coe * temp;
    end
    val = const/(6*t + 2)^(3/4)/(3*t + 1)^(3/2) * exp(-3/2*(3*t + 1)) * val;
    val = imag(val);
end