function val = Analytic(x, y, z, t)
    val = 1/sqrt(3*t + 1)/(3*t + 1) * sin(x + 6*y/5 + z/2) .* exp(-x.^2/(6*t + 2) - y.^2/(6*t + 2) - z.^2/(6*t + 2));
end