clear

% spectral method parameters
alpha = [0, 0, 0];
beta = [0.3, 0.3, 0.3];
N = 25; gamma = 10;
[Nx, Ny, Nz] = Hyperbolic(N, gamma);

% initialization
[col_x, wx] = Quad(N, alpha(1), beta(1));
[col_y, wy] = Quad(N, alpha(2), beta(2));
[col_z, wz] = Quad(N, alpha(3), beta(3));
[X, Y, Z] = ndgrid(col_x, col_y, col_z);
[wx, wy, wz] = ndgrid(wx, wy, wz); w = wx .* wy .* wz;
[Proj, Inv] = P2matrix(N, alpha, beta, Nx, Ny, Nz);

u = Analytic(X, Y, Z, 0.1);
uvec = Vec(u);
coe = Proj * uvec;
frequency = Frequency_indicator(coe, N, gamma, Nx, Ny, Nz)
uinv = Inv * coe;
max(uinv - Vec(u))

d2matrix = D2matrix(N, beta, Nx, Ny, Nz);
coe = d2matrix * coe;
Finv = Inv * coe;
f = F(X, Y, Z, 0.1);
sum((Finv - Vec(f)).^2)