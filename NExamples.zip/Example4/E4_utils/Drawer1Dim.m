% figure
yyaxis left
plot(0 : 0.1 : 1, N1, 'Linewidth', 3, 'color',  [188, 85, 101]/255)
hold on
plot(0 : 0.1 : 1, N2, 'Linewidth', 3, 'color', [247, 209, 118]/255)
plot(0 : 0.3 : 1, N1(1 : 3 : 11), 'o', 'Linewidth', 2, 'Color', [188, 85, 101]/255)
plot(0 : 0.3 : 1, N2(1 : 3 : 11), '<', 'Linewidth', 2, 'Color', [247, 209, 118]/255)
set(gca,'ycolor','k');
yyaxis right
plot(0 : 0.1 : 1, NC2, '--', 'Linewidth', 3, 'color', [247, 209, 118]/255)
hold on
plot(0 : 0.1 : 1, NC1, '--', 'Linewidth', 3, 'color', [188, 85, 101]/255)
set(gca, 'ycolor','k');
print('-dpdf','N')

% t = 0.1 : 0.1 : 1;
% mark = 1 : 3 : 10;
% figure
% semilogy(t, L1, 'Linewidth', 3, 'Color', [193, 185, 174]/255)
% hold on
% semilogy(t, L2, 'Linewidth', 3, 'Color', [56, 104, 166]/255)
% semilogy(t(1 : 7), L3, 'Linewidth', 3, 'Color', [247, 209, 118]/255)
% semilogy(t, L4, 'Linewidth', 3, 'Color', [188, 85, 101]/255)
% legend('nonadaptive', 'scaled only', 'full tensor adaptive', 'hyperbolic adaptive')
% semilogy(t(mark), L1(mark), 's', 'Linewidth', 2, 'Color', [193, 185, 174]/255)
% semilogy(t(mark), L2(mark), '>', 'Linewidth', 2, 'Color', [56, 104, 166]/255)
% semilogy(t(1 : 3 : 7), L3(1 : 3 : 7), '<', 'Linewidth', 2, 'Color', [247, 209, 118]/255)
% semilogy(t(mark), L4(mark), 'o', 'Linewidth', 2, 'Color', [188, 85, 101]/255)
% 
% set(gca, 'yminortick', 'off')

% t = 0 : 0.1 : 1;
% mark = 1 : 3 : 11;
% figure
% plot(t, L2, 'Linewidth', 3, 'Color', [56, 104, 166]/255)
% hold on
% semilogy(t(1 : 8), L3, 'Linewidth', 3, 'Color', [247, 209, 118]/255)
% semilogy(t, L4, 'Linewidth', 3, 'Color', [188, 85, 101]/255)
% legend('scaled only', 'full tensor adaptive', 'hyperbolic adaptive')
% semilogy(t(mark), L2(mark), '>', 'Linewidth', 2, 'Color', [56, 104, 166]/255)
% semilogy(t(1 : 3 : 8), L3(1 : 3 : 8), '<', 'Linewidth', 2, 'Color', [247, 209, 118]/255)
% semilogy(t(mark), L4(mark), 'o', 'Linewidth', 2, 'Color', [188, 85, 101]/255)
% 
% set(gca, 'yminortick', 'off')