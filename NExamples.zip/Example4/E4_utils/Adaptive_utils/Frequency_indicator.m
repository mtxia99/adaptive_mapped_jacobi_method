function freq = Frequency_indicator(coe, N, gamma, Nx, Ny, Nz, direction)
    if nargin == 6
        freq = [Fx(coe, N, gamma, Nx, Ny, Nz);
                Fy(coe, N, gamma, Nx, Ny, Nz);
                Fz(coe, N, gamma, Nx, Ny, Nz)];
    elseif strcmp(direction, 'y')
        freq = Fy(coe, N, gamma, Nx, Ny, Nz);
    elseif strcmp(direction, 'x')
        freq = Fx(coe, N, gamma, Nx, Ny, Nz);
    elseif strcmp(direction, 'z')
        freq = Fz(coe, N, gamma, Nx, Ny, Nz);
    end
end

function fx = Fx(coe, N, gamma, Nx, Ny, Nz)
    total = sum(coe.^2); res = 0;
    NC = length(Nx);
    for n = 1 : NC
        if max(1, 3/2 * Nx(n)) * max(1, Ny(n)) * max(1, Nz(n)) * max(3/2 * Nx(n), max(Ny(n), Nz(n)))^gamma > N^(1 + gamma)
            res = res + coe(n)^2;
        end
    end
    fx = sqrt(res/total);
end

function fy = Fy(coe, N, gamma, Nx, Ny, Nz)
    total = sum(coe.^2); res = 0;
    NC = length(Ny);
    for n = 1 : NC
        if max(1, Nz(n)) * max(1, Nx(n)) * max(1, 3/2 * Ny(n)) * max(max(Nx(n), Nz(n)), 3/2 * Ny(n))^gamma > N^(1 + gamma)
            res = res + coe(n)^2;
        end
    end
    fy = sqrt(res/total);
end

function fz = Fz(coe, N, gamma, Nx, Ny, Nz)
    total = sum(coe.^2); res = 0;
    NC = length(Nz);
    for n = 1 : NC
        if max(1, 3/2 * Nz(n)) * max(1, Nx(n)) * max(1, Ny(n)) * max(max(Nx(n), Ny(n)), 3/2 * Nz(n))^gamma > N^(1 + gamma)
            res = res + coe(n)^2;
        end
    end
    fz = sqrt(res/total);
end