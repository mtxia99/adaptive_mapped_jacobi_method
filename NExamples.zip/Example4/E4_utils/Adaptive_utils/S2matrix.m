function s2matrix = S2matrix(N, q, Nx, Ny, Nz)
    [col_x, wx] = Quad(N, 0, q(1));
    [col_y, wy] = Quad(N, 0, q(2));
    [col_z, wz] = Quad(N, 0, q(3));
    
    [X, Y, Z] = ndgrid(col_x, col_y, col_z);
    [wx, wy, wz] = ndgrid(wx, wy, wz);
    w = wx .* wy .* wz;
    
    NC = length(Nx);
    Proj = zeros(NC, N^3); Inv = zeros(N^3, NC);
    for ell = 1 : NC
        nx = Nx(ell); ny = Ny(ell); nz = Nz(ell);
        B2vec = Basis(X, nx, 0, q(1)) .* Basis(Y, ny, 0, q(2)) .* Basis(Z, nz, 0, q(3));
        P2vec = Vec(B2vec .* w); Proj(ell, :) = P2vec;
        
        B2vec = Basis(X, nx, 0, 1) .* Basis(Y, ny, 0, 1) .* Basis(Z, nz, 0, 1);
        I2vec = Vec(B2vec); Inv(:, ell) = I2vec';
    end
    s2matrix = Proj * Inv;
end