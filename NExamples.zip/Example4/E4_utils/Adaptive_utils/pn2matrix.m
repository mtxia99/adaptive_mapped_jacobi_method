function p2matrix = pn2matrix(N, gamma, alpha, beta, Nx, Ny, Nz)
    [col_x, wx] = Quad(N, alpha(1), beta(1));
    [col_y, wy] = Quad(N, alpha(2), beta(2));
    [col_z, wz] = Quad(N, alpha(3), beta(3));
    
    [X, Y, Z] = ndgrid(col_x, col_y, col_z);
    [wx, wy, wz] = ndgrid(wx, wy, wz);
    w = wx .* wy .* wz;
    
    [Nx_new, Ny_new, Nz_new] = Hyperbolic(N, gamma);
    NC = length(Nx); NC_new = length(Nx_new);
    
    Proj = zeros(NC_new, N^3); Inv = zeros(N^3, NC);
    for ell = 1 : NC_new
        nx = Nx_new(ell); ny = Ny_new(ell); nz = Nz_new(ell);
        B2vec = Basis(X, nx, alpha(1), beta(1)) .* Basis(Y, ny, alpha(2), beta(2)) .* Basis(Z, nz, alpha(3), beta(3));
        P2vec = Vec(B2vec .* w);
        Proj(ell, :) = P2vec;
    end 
    for ell = 1 : NC
        nx = Nx(ell); ny = Ny(ell); nz = Nz(ell);
        B2vec = Basis(X, nx, alpha(1), beta(1)) .* Basis(Y, ny, alpha(2), beta(2)) .* Basis(Z, nz, alpha(3), beta(3));
        I2vec = Vec(B2vec); Inv(:, ell) = I2vec';
    end
    p2matrix = Proj * Inv;
end