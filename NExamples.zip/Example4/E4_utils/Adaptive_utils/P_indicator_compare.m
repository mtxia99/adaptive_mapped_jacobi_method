function freq = P_indicator_compare(coe, N, gamma, Nx, Ny, Nz)
    fx = Fx(coe, N, gamma, Nx, Ny, Nz); fy = Fy(coe, N, gamma, Nx, Ny, Nz);
    fz = Fz(coe, N, gamma, Nx, Ny, Nz);
    freq = sqrt(fx^2 + fy^2 + fz^2);
end

function fx = Fx(coe, N, gamma, Nx, Ny, Nz)
    total = sum(coe.^2); res = 0;
    NC = length(Nx);
    for n = 1 : NC
        if Nx(n) > floor((2 * N + 2)/3)
            res = res + coe(n)^2;
        end
    end
    fx = sqrt(res/total);
end

function fy = Fy(coe, N, gamma, Nx, Ny, Nz)
    total = sum(coe.^2); res = 0;
    NC = length(Ny);
    for n = 1 : NC
        if Ny(n) > floor((2 * N + 2)/3)
            res = res + coe(n)^2;
        end
    end
    fy = sqrt(res/total);
end

function fz = Fz(coe, N, gamma, Nx, Ny, Nz)
    total = sum(coe.^2); res = 0;
    NC = length(Nz);
    for n = 1 : NC
        if Nz(n) > floor((2 * N + 2)/3)
            res = res + coe(n)^2;
        end
    end
    fz = sqrt(res/total);
end