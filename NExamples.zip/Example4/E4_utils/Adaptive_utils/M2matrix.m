function m2matrix = M2matrix(N, d, beta, Nx, Ny, Nz)
    [col_x, wx] = Quad(N, d(1), beta(1));
    [col_y, wy] = Quad(N, d(2), beta(2));
    [col_z, wz] = Quad(N, d(3), beta(3));
    
    [X, Y, Z] = ndgrid(col_x, col_y, col_z);
    [wx, wy, wz] = ndgrid(wx, wy, wz);
    w = wx .* wy .* wz;
    
    NC = length(Nx);
    Proj = zeros(NC, N^3); Inv = zeros(N^3, NC);
    for ell = 1 : NC
        nx = Nx(ell); ny = Ny(ell); nz = Nz(ell);
        B2vec = Basis(X, nx, d(1), beta(1)) .* Basis(Y, ny, d(2), beta(2)) .* Basis(Z, nz, d(3), beta(3));
        P2vec = Vec(B2vec .* w); Proj(ell, :) = P2vec;
        
        B2vec = Basis(X, nx, 0, beta(1)) .* Basis(Y, ny, 0, beta(2)) .* Basis(Z, nz, 0, beta(3));
        I2vec = Vec(B2vec); Inv(:, ell) = I2vec';
    end
    m2matrix = Proj * Inv;
end