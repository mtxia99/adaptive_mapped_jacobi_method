function [col, w] = Quad(N, alpha, beta)
    col = zeros(1, N);
    for m = 1 : N
        temp = -cos((2*(m - 1) + 1) * pi/(2*N));
        col(m) = 1/beta/2 * log((1 + temp)/(1 - temp));
    end
    w = pi/N * cosh(beta * col)/beta;
    col = col + alpha;
end