function val = Basis(x, N, alpha, beta)
    x = tanh((x - alpha) * beta);
    val = Chebyshev(x, N);
    if N == 0
        gamma = pi;
    else
        gamma = pi/2;
    end
    val = sqrt(beta/gamma) * val .* (1 - x.^2).^(1/4);
end