function d2matrix = D2matrix(N, beta, Nx, Ny, Nz)
    NC = length(Nx);

    Dx = DF1mat(N, beta(1));
    Dy = DF1mat(N, beta(2));
    Dz = DF1mat(N, beta(3));
    
    [Vx, Ex] = eig(Dx, 'vector');
    [Vy, Ey] = eig(Dy, 'vector');
    [Vz, Ez] = eig(Dz, 'vector');
    
    E = zeros(N^3, 1);
    for nx = 1 : N
        for ny = 1 : N
            for nz = 1 : N
                E(nx + N * (ny - 1) + N^2 * (nz - 1)) = (Ex(nx) + Ey(ny) + Ez(nz))^(3/4);
            end
        end
    end
    
    V = zeros(NC, N^3);
    for ell = 1 : NC
        for nx = 1 : N
            for ny = 1 : N
                for nz = 1 : N
                    V(ell, nx + N * (ny - 1) + N^2 * (nz - 1)) = Vx(Nx(ell) + 1, nx) * Vy(Ny(ell) + 1, ny) * Vz(Nz(ell) + 1, nz);
                end
            end
        end
    end
    ind = 1 : length(E);
    s = sparse(ind, ind, E);
    d2matrix = V * s * V';
end

function A = DF1mat(N, beta)
    gamma = pi/2 * ones(N, 1); gamma(1) = pi;
    A = zeros(N);
    for m = 0 : N - 1
        for n = 0 : N - 1
            if m == n
                res =  (2 * m - 1)^2 + (2 * m + 1)^2 + 2 * Delta(m, 0) + Delta(m, 1);
                A(m + 1, n + 1) = res * beta^2 * pi/32/sqrt(gamma(m + 1)*gamma(n + 1));
            elseif m == n + 2
                res = -(2*m - 1) * (2*m - 3) - 3 * Delta(m, 2);
                A(m + 1, n + 1) = res * beta^2 * pi/32/sqrt(gamma(m + 1)*gamma(n + 1));
            elseif m == n - 2
                res = -(2*m + 1) * (2*m + 3) - 3 * Delta(m, 0);
                A(m + 1, n + 1) = res * beta^2 * pi/32/sqrt(gamma(m + 1)*gamma(n + 1));
            end
        end
    end
end

function val = Delta(m, n)
    if m == n
        val = 1;
    else
        val = 0;
    end
end