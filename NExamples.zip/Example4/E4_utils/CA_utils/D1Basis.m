function val = D1Basis(x, N, alpha, beta)
    x = tanh((x - alpha) * beta);
    val = (2*N - 1)/4 * Chebyshev(x, N - 1) - (2*N + 1)/4 * Chebyshev(x, N + 1);
    if N == 0
        gamma = pi;
    else
        gamma = pi/2;
    end
    val = beta * sqrt(beta/gamma) * val .*(1 - x.^2).^(1/4);
end
