NC = zeros(1, 11);
for ell = 1 : 11
    [Nx, Ny] = Hyperbolic(N(ell), 10);
    NC(ell) = length(Nx);
end