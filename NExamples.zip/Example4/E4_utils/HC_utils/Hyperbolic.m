function [Nx, Ny, Nz] = Hyperbolic(N, gamma)
    [X, Y, Z] = ndgrid(0:N-1, 0:N-1, 0:N-1);
    Nx = zeros(1, N^3); Ny = zeros(1, N^3); Nz = zeros(1, N^3);
    
    rec = 0;
    for ell = 1 : N
        for nu = 1 : N
            for bm = 1 : N
                if max(1, X(ell, nu, bm)) * max(1, Y(ell, nu, bm)) * max(1, Z(ell, nu, bm)) * max(X(ell, nu, bm), max(Y(ell, nu, bm), Z(ell, nu, bm)))^gamma <= N^(1 + gamma)
                    rec = rec + 1;
                    Nx(rec) = ell - 1;
                    Ny(rec) = nu - 1;
                    Nz(rec) = bm - 1;
                end
            end
        end
    end
    Nx = Nx(1 : rec); Ny = Ny(1 : rec); Nz = Nz(1 : rec);
end