function v = Vec(u)
    [M, N, B] = size(u);
    v = zeros(M * N * B, 1);
    for ell = 1 : M
        for nu = 1 : N
            for bm = 1 : B
                v(ell + M * (nu - 1) + M * N * (bm - 1)) = u(ell, nu, bm);
            end
        end
    end
end