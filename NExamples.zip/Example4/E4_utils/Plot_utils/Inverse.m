function val = Inverse(X, Y, Z, coe, alpha, beta, Nx, Ny, Nz)
    val = zeros(size(X));
    for ell = 1 : length(Nx)
        val = val + coe(ell) * Basis(X, Nx(ell), alpha(1), beta(1)) .* Basis(Y, Ny(ell), alpha(2), beta(2)) .* Basis(Z, Nz(ell), alpha(3), beta(3));
    end
end