x = linspace(-10, 10, 1000);
figure
hold on
for ell = 1: 10: 100
   plot(x, Inverse(x, Coe(:, ell + 1), alpha(ell), beta(ell)), 'Linewidth', 2 * ell/100, 'color', [0, 100 - ell, ell]/100)
end

figure
plot(0.1 : 0.1 : 10, frequency_recorder, 'Linewidth', 3)