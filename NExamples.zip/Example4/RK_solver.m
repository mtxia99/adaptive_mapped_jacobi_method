function u = RK_solver(u0, tau, Fmat, d2matrix)
    % RK method of 4th order
    [A, b] = RK_coe;
    
    % stage variables
    K = cat(2, u0, u0, u0, u0);
    [N, ~] = size(K);
    
    % iteration initialize
    coVec = K/A + tau * Fmat;
    alpha = 1; w = 0;
    
    B = inv(alpha * eye(4) + inv(A));
    C = inv(alpha * eye(N) + tau * d2matrix);
    itermax = 500;
    for iter = 1 : itermax
        f = alpha * K - K/A + coVec;
        K2 = C * f;
        K = (K/A - (1 - w) * K * alpha + (2 - w) * alpha * K2) * B;
        
        val = K/A + tau * d2matrix * K - coVec;
        converge = sqrt(sum(sum(val.^2))/N)
        if sqrt(sum(sum(val.^2))/N) <= 1e-12
            break
        end
    end
    u = u0 + tau * (Fmat - d2matrix * K) * b;
end


function [A, b] = RK_coe(~)
    A = [0.086964, -0.026604, 0.012627, -0.0035551;
        0.18812, 0.16304, -0.02788, 0.0067355;
        0.16719, 0.35395, 0.16304, -0.014191;
        0.17748, 0.31345, 0.35268, 0.086964];
    A = A';
    
    b = [0.17393; 0.32607; 0.32607; 0.17393];
end