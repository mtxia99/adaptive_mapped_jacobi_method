% x = linspace(0, 8, 1000);
% 
% figure
% for ell = 5: 10: 25
%    plot(x, abs(Inverse(x, Coe(:, ell + 1), alpha(ell), beta(ell)) - Analytic(x, 0.1 * ell)), 'Linewidth', 1 + 1.5 * ell/30, 'color', [0, 30 - ell, ell]/30)
%    hold on
% %    plot(x(1 : 40: 1000), abs(Inverse(x(1 : 40: 1000), Coe(:, ell + 1), alpha(ell), beta(ell)) - Analytic(x(1 : 40: 1000), 0.1 * ell)), 'o', 'Linewidth', 1, 'color', [0, 30 - ell, ell]/30)
% end
% print('-dpdf','logdist')

% figure
yyaxis left
plot(0 : 0.1 : 3, beta, 'Linewidth', 3, 'color', [56, 104, 166]/255)
hold on
plot(0 : 0.3 : 3, beta(1 : 3 : 31), 'o', 'Linewidth', 2, 'Color', [56, 104, 166]/255)
ylim([0, 1])
yyaxis right
plot(0 : 0.1 : 3, alpha, 'Linewidth', 3, 'color', [247, 209, 118]/255)
hold on
plot(0 : 0.3 : 3, alpha(1 : 3 : 31), '<', 'Linewidth', 2, 'Color', [247, 209, 118]/255)
set(gca, 'yminortick', 'off')
print('-dpdf','scale')