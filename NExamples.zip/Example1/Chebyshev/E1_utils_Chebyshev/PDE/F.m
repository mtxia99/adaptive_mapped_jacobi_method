function Fval = F(x, t)
    Fval = 12 * (t + 1)^11 * x.^2./((t + 1)^2 + x.^2).^7 + (1 + t)^12./((t + 1)^2 + x.^2).^6 .* (1 - (1 + t)^24./((1 + t)^2 + x.^2).^12);
    Fval = Fval + Frac(x, t);
end

function val = Frac(x, t)
    N = 1e6;
    xval = x/(t + 1);
    basis = ones(size(x)); coe = 1; val = ones(size(x));
    for n = 0 : N
        basis = basis .* (xval.^2./(1 + xval.^2));
        coe = coe * (6 + 1/2 + n) * (n - 1/2)/(n + 1)/(n + 1/2);
        val = val + basis * coe;
    end
    const = (3 * 5 * 7 * 9 * 11)/(2 * 4 * 6 * 8 * 10)./(1 + xval.^2).^(13/2)/(t + 1);
    val = const .* val;
end