function u = D1nonlinear(u)
    u = 1 - 3 * u.^2;
end