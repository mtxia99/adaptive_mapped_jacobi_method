function u = Nonlinear(u)
    u = u .* (1 - u.^2);
end