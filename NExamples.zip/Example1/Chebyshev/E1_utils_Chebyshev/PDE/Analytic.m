function val = Analytic(x, t)
    val = 1./(1 + (x/(t + 1)).^2).^6;
end