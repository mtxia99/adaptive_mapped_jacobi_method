function Resplot(u, v)
    figure
    imagesc(u - v)
    colorbar
    axis square
    colormap(othercolor('BuDRd_12'))
end