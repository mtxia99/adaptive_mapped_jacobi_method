x = linspace(0, 12, 1000);

y1 = exp(-x.^2/2);
y2 = 1./(1 + x.^2);
y3 = 1./(1 + (x/2).^2).^6;
semilogy(x, y1, 'Linewidth', 2)
hold on
semilogy(x, y2, 'Linewidth', 2)
semilogy(x, y3, 'Linewidth', 3)
print('-dpdf', 'Fig3')