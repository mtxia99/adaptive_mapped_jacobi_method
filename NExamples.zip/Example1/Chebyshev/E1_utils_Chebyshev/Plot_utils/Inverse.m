function val = Inverse(x, coe, alpha, beta)
    val = zeros(size(x));
    for ell = 0 : length(coe) - 1
        val = val + coe(ell + 1) * Basis(x, ell, alpha, beta);
    end
end