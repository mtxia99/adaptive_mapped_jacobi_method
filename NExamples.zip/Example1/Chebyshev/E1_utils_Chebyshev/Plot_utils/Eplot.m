function Eplot(L)
    [M, N] = size(L);
    
    if N == 30
        t = 0.1:0.1:3;
        mark = 1 : 3 : 30;
    elseif N == 31
        t = 0:0.1:3;
        mark = 1 : 3 : 31;
    end
    
    if M == 2
        mark1 = 1 : 6 : 31;
        mark2 = 4 : 6 : 31;
        figure
        plot(t, L(1, :), 'Linewidth', 3, 'Color', [247, 209, 118]/255)
        hold on
        plot(t, L(2, :), 'Linewidth', 3, 'Color', [188, 85, 101]/255)
        legend('nonadaptive', 'scaled only', 'location', 'northwest')
        plot(t(mark1), L(1, mark1), '<', 'Linewidth', 2, 'Color', [247, 209, 118]/255)
        plot(t(mark2), L(2, mark2), 'o', 'Linewidth', 2, 'Color', [188, 85, 101]/255)

        set(gca, 'yminortick', 'off')
    
    elseif M == 4
        figure
        semilogy(t, L(1, :), 'Linewidth', 3, 'Color', [193, 185, 174]/255)
        hold on
        semilogy(t, L(2, :), 'Linewidth', 3, 'Color', [56, 104, 166]/255)
        semilogy(t, L(3, :), 'Linewidth', 3, 'Color', [247, 209, 118]/255)
        semilogy(t, L(4, :), 'Linewidth', 3, 'Color', [188, 85, 101]/255)
        legend('nonadaptive', 'scaled only', 'full tensor adaptive', 'hyperbolic adaptive')
        semilogy(t(mark), L(1, mark), 's', 'Linewidth', 2, 'Color', [193, 185, 174]/255)
        semilogy(t(mark), L(2, mark), '>', 'Linewidth', 2, 'Color', [56, 104, 166]/255)
        semilogy(t(mark), L(3, mark), '<', 'Linewidth', 2, 'Color', [247, 209, 118]/255)
        semilogy(t(mark), L(4, mark), 'o', 'Linewidth', 2, 'Color', [188, 85, 101]/255)

        set(gca, 'yminortick', 'off')
    elseif M == 3
        figure
        plot(t, L(1, :), 'Linewidth', 3, 'Color', [56, 104, 166]/255)
        hold on
        plot(t, L(2, :), 'Linewidth', 3, 'Color', [247, 209, 118]/255)
        plot(t, L(3, :), 'Linewidth', 3, 'Color', [188, 85, 101]/255)
        legend( 'scaled only', 'full tensor adaptive', 'hyperbolic adaptive')
        plot(t(mark), L(1, mark), '>', 'Linewidth', 2, 'Color', [56, 104, 166]/255)
        plot(t(mark), L(2, mark), '<', 'Linewidth', 2, 'Color', [247, 209, 118]/255)
        plot(t(mark), L(3, mark), 'o', 'Linewidth', 2, 'Color', [188, 85, 101]/255)

        set(gca, 'yminortick', 'off')
    elseif M == 8
        t = 0.1:0.1:3;
        mark1 = 1 : 6 : 30;
        mark2 = 3 : 6 : 30;
        figure
        semilogy(t, L(1, :), 'Linewidth', 3, 'Color', [193, 185, 174]/255)
        hold on
        semilogy(t, L(2, :), 'Linewidth', 3, 'Color', [56, 104, 166]/255)
        semilogy(t, L(3, :), 'Linewidth', 3, 'Color', [247, 209, 118]/255)
        semilogy(t, L(4, :), 'Linewidth', 3, 'Color', [188, 85, 101]/255)
        legend('nonadaptive', 'scaled only', 'full tensor adaptive', 'hyperbolic adaptive')
        semilogy(t(mark1), L(1, mark1), 's', 'Linewidth', 2, 'Color', [193, 185, 174]/255)
        semilogy(t(mark1), L(2, mark1), '>', 'Linewidth', 2, 'Color', [56, 104, 166]/255)
        semilogy(t(mark1), L(3, mark1), '<', 'Linewidth', 2, 'Color', [247, 209, 118]/255)
        semilogy(t(mark1), L(4, mark1), 'o', 'Linewidth', 2, 'Color', [188, 85, 101]/255)
        
        semilogy(t, L(5, :), '--', 'Linewidth', 3, 'Color', [193, 185, 174]/255)
        semilogy(t, L(6, :), '--', 'Linewidth', 3, 'Color', [56, 104, 166]/255)
        semilogy(t, L(7, :), '--','Linewidth', 3, 'Color', [247, 209, 118]/255)
        semilogy(t, L(8, :), '--','Linewidth', 3, 'Color', [188, 85, 101]/255)
        semilogy(t(mark2), L(5, mark2), 's', 'Linewidth', 2, 'Color', [193, 185, 174]/255)
        semilogy(t(mark2), L(6, mark2), '>', 'Linewidth', 2, 'Color', [56, 104, 166]/255)
        semilogy(t(mark2), L(7, mark2), '<', 'Linewidth', 2, 'Color', [247, 209, 118]/255)
        semilogy(t(mark2), L(8, mark2), 'o', 'Linewidth', 2, 'Color', [188, 85, 101]/255)

        set(gca, 'yminortick', 'off')
    elseif M == 6
        t = 0:0.1:3;
        mark1 = 1 : 6 : 31;
        mark2 = 3 : 6 : 31;
        figure
        plot(t, L(1, :), 'Linewidth', 3, 'Color', [56, 104, 166]/255)
        hold on
        plot(t, L(2, :), 'Linewidth', 3, 'Color', [247, 209, 118]/255)
        plot(t, L(3, :), 'Linewidth', 3, 'Color', [188, 85, 101]/255)
        legend('scaled only', 'full tensor adaptive', 'hyperbolic adaptive')
        plot(t(mark1), L(1, mark1), '>', 'Linewidth', 2, 'Color', [56, 104, 166]/255)
        plot(t(mark1), L(2, mark1), '<', 'Linewidth', 2, 'Color', [247, 209, 118]/255)
        plot(t(mark1), L(3, mark1), 'o', 'Linewidth', 2, 'Color', [188, 85, 101]/255)
        
        plot(t, L(4, :), '--', 'Linewidth', 3, 'Color', [56, 104, 166]/255)
        plot(t, L(5, :), '--','Linewidth', 3, 'Color', [247, 209, 118]/255)
        plot(t, L(6, :), '--','Linewidth', 3, 'Color', [188, 85, 101]/255)
        plot(t(mark2), L(4, mark2), '>', 'Linewidth', 2, 'Color', [56, 104, 166]/255)
        plot(t(mark2), L(5, mark2), '<', 'Linewidth', 2, 'Color', [247, 209, 118]/255)
        plot(t(mark2), L(6, mark2), 'o', 'Linewidth', 2, 'Color', [188, 85, 101]/255)

        set(gca, 'yminortick', 'off')
    end
end