function Heatmap(u)
    figure
    imagesc(u, [0, 1])
    set(gca, 'xtick', 0:100:1000)
    set(gca, 'xticklabel', {'-5', '-4', '-3', '-2', '-1', '0', '1', '2', '3', '4', '5'})
    set(gca, 'ytick', 0:100:1000)
    set(gca, 'yticklabel', {'-5', '-4', '-3', '-2', '-1', '0', '1', '2', '3', '4', '5'})
    colorbar
    axis square
    colormap(othercolor('BuDRd_12'))
end