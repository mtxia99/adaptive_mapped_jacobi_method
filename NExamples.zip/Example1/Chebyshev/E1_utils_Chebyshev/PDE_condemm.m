clear

alpha = 0;
beta = 0.5;
N = 64;

% initialization
[col, w] = Quad(N, alpha, beta);
[Proj, Inv] = P1matrix(N, alpha, beta);
% Proj * Inv
u = Analytic(col, 0);
coe = Proj * u';

d2matrix = D2matrix(N, beta);
Dproj = D1matrix(N, alpha, beta);
Dinv = D1inv(N, alpha, beta);
sinv = Sinv(N, alpha, beta);

Uint = 2 * sinv * coe - 1;
U = Inv * coe;
Nonlinear(coe, Dproj, Inv, sinv)
% d2matrix - Dproj * Dinv'

coe = d2matrix * coe/2 + Nonlinear(coe, Dproj, Inv, sinv)
% Inv * coe

