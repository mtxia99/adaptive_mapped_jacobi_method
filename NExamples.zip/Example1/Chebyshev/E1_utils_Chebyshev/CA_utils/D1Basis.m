function val = D1Basis(x, N, alpha, beta)
    x = ((x - alpha) * beta)./sqrt(1 + ((x - alpha) * beta).^2);
    val = (N - 1)/2 * Chebyshev(x, N - 1) - (N + 1)/2 * Chebyshev(x, N + 1);
    if N == 0
        gamma = pi;
    else
        gamma = pi/2;
    end
    val = beta * sqrt(beta/gamma) * val .*(1 - x.^2);
end
