function y = Chebyshev(x, n)
    if n < 0
        y = x;
    elseif n == 0
        y = ones(size(x));
    elseif n == 1
        y = x;
    else
        y1 = ones(size(x));
        y2 = x;
        for i = 1 : n-1
            y3 = 2 * x .* y2 - y1;
            y1 = y2;
            y2 = y3;
        end
        y = y2;
    end
end