function d2matrix = D2matrix(N, beta)
    D = DF1mat(N, beta); [V, E] = eig(D, 'vector');
    E = sqrt(E);
    d2matrix = V * diag(E) * V';
end

function A = DF1mat(N, beta)
    gamma = pi/2 * ones(N, 1); gamma(1) = pi;
    A = zeros(N);
    for m = 0 : N - 1
        for n = 0 : N - 1
            if m == n
                res = 6 * m^2 + 2 + 2 * Delta(m, 0) - Delta(m, 2);
                A(m + 1, n + 1) = res * beta^2 * pi/32/sqrt(gamma(m + 1)*gamma(n + 1));
            elseif m == n + 2
                res = -4 * (m^2 - 2*m + 1) - 4 * Delta(m, 2);
                A(m + 1, n + 1) = res * beta^2 * pi/32/sqrt(gamma(m + 1)*gamma(n + 1));
            elseif m == n - 2
                res = -4 * (m^2 + 2*m + 1) - 4 * Delta(m, 0);
                A(m + 1, n + 1) = res * beta^2 * pi/32/sqrt(gamma(m + 1)*gamma(n + 1));
            elseif m == n + 4
                res = m^2 - 4*m + 3 + 3 * Delta(m, 4);
                A(m + 1, n + 1) = res * beta^2 * pi/32/sqrt(gamma(m + 1)*gamma(n + 1));
            elseif m == n - 4
                res = m^2 + 4*m + 3 + 3 * Delta(m, 0);
                A(m + 1, n + 1) = res * beta^2 * pi/32/sqrt(gamma(m + 1)*gamma(n + 1));
            end
        end
    end
end

function val = Delta(m, n)
    if m == n
        val = 1;
    else
        val = 0;
    end
end