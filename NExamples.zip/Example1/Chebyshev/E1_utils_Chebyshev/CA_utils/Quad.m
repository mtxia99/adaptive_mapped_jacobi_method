function [col, w] = Quad(N, alpha, beta)
    col = zeros(1, N);
    for m = 1 : N
        temp = -cos((2*(m - 1) + 1) * pi/(2*N));
        col(m) = temp/beta/sqrt(1 - temp^2);
    end
    w = pi/N * (beta * col.^2 + 1/beta);
    col = col + alpha;
end