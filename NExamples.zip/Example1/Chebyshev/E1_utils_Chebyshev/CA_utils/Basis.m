function val = Basis(x, N, alpha, beta)
    mu = sqrt(1 + ((x - alpha) * beta).^2);
    z = ((x - alpha) * beta)./mu;
    val = Chebyshev(z, N);
    if N == 0
        gamma = pi;
    else
        gamma = pi/2;
    end
    val = sqrt(beta/gamma) * val./mu;
end