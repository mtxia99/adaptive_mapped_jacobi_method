tau = 0.1;
t = 0 : tau : 1;
reference = exp(-20*t);
N = length(t);
rec = zeros(1, N);
rec(1) = 1;

for ell = 1 : N - 1
    rec(ell + 1) = RK_solver(rec(ell), tau, [0, 0, 0, 0], 20, 1, 1);
end
rec - reference