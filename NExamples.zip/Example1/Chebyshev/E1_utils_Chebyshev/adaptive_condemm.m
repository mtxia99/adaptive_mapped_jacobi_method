alpha = [1, 0];
beta = [0.9, 0.9];
N = 30; gamma = 4;
[Nx, Ny] = Hyperbolic(N, gamma);

% initialization
[col_x, wx] = Quad(N, alpha(1), beta(1));
[col_y, wy] = Quad(N, alpha(2), beta(2));
[X, Y] = ndgrid(col_x, col_y);
[wx, wy] = ndgrid(wx, wy); w = wx .* wy;
[Proj, Inv] = P2matrix(N, alpha, beta, Nx, Ny);

u = Analytic(X, Y, 0);
uvec = Vec(u);
coe = Proj * uvec;

% adaptive recorders
freq = Frequency_indicator(coe, N, gamma, Nx, Ny);
exte = Exterior_error_indicator(coe, N, beta, Nx, Ny)  %xR, yR, xL, yL
