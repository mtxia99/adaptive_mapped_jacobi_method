function s2matrix = S2matrix(N, q)
    [col, w] = Quad(N, 0, q);

    Proj = zeros(N, N); Inv = zeros(N, N);
    for ell = 1 : N
        Proj(ell, :) = Basis(col, ell - 1, 0, q).* w;
        Inv(:, ell) = Basis(col, ell - 1, 0, 1)';
    end
    s2matrix = Proj * Inv;
end