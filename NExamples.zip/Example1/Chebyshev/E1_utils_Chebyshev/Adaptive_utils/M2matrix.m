function m2matrix = M2matrix(N, d, beta)
    [col, w] = Quad(N, d, beta);
    
    Proj = zeros(N, N); Inv = zeros(N, N);
    for ell = 1 : N
        Proj(ell, :) = Basis(col, ell - 1, d, beta).* w;
        Inv(:, ell) = Basis(col, ell - 1, 0, beta)';
    end
    m2matrix = Proj * Inv;
end