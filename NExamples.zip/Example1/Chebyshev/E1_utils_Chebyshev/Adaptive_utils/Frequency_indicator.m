function freq = Frequency_indicator(coe, N)
    total = sum(coe.^2); res = 0;
    for n = 1 : N
        if n > floor((2*N + 2)/3)
            res = res + coe(n)^2;
        end
    end
    freq = sqrt(res/total);
end
