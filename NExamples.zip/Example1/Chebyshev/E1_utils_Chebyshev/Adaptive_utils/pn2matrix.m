function p2matrix = pn2matrix(N, dN, alpha, beta)
    [col, w] = Quad(N, alpha, beta);
    
    Proj = zeros(N + dN, N); Inv = zeros(N, N);
    for ell = 1 : N + dN
        Proj(ell, :) = Basis(col, ell - 1, alpha, beta) .* w;
    end 
    for ell = 1 : N
        Inv(:, ell) = Basis(col, ell - 1, alpha, beta)';
    end
    p2matrix = Proj * Inv;
end