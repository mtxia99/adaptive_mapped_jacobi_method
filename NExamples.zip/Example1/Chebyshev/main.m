clear;
addpath(genpath('E1_utils_Chebyshev'))
% spatiotemporal parameters
T = 3; dt = 0.1;
time = 0 : dt : T;
KT = length(time);

% spectral method parameters
alpha = zeros(1, KT);
beta = 0.75 * ones(1, KT);
N = 64 * ones(KT);

% initialization
[col, w] = Quad(N(1), alpha(1), beta(1));
[Proj, Inv] = P1matrix(N(1), alpha(1), beta(1));

u = Analytic(col, 0);
coe = Proj * u';

% Recorders
Error = zeros(1, KT - 1);

% adaptive recorders
freq = Frequency_indicator(coe, N(1))
exte = Exterior_error_indicator(coe, N(1), beta(:, 1));  %xR, xL
Frequency_res = freq * ones(1, KT - 1);
Exterior_res = exte * ones(1, KT - 1);
P_res = freq;

frequency_recorder = Frequency_res;
exterior_recorder = Exterior_res;

Xmax = 0.05; d = 0.01; mu = 1.0005;
betamin = 0; q = 0.99;
eta = 4; eg = 1.2; Nmax = 5;
for ell = 1 : KT - 1
    % initialize
    [col, w] = Quad(N(ell), alpha(ell), beta(ell));
    [Proj, Inv] = P1matrix(N(ell), alpha(ell), beta(ell));

    d2matrix = D2matrix(N(ell), beta(ell));

    % RK method
    stage = time(ell) + dt * [0.069432, 0.33001, 0.66999, 0.93057];
    Fmat = zeros(N(ell), 4);
    for s = 1 : 4
        Fmat(:, s) = F(col, stage(s));
    end
    Fmat = Proj * Fmat;
    
    coe = RK_solver(coe, dt, Fmat, d2matrix, Proj, Inv);
    
    % Record error
    uinv = Inverse(col, coe, alpha(ell), beta(ell));
    ref = Analytic(col, time(ell + 1));
    error = sqrt(sum((ref - uinv).^2 .* w))/sqrt(sum((ref).^2 .* w))
    Error(ell) = error;
    
    % moving
    exte = Exterior_error_indicator(coe, N(ell), beta(ell));
    
    xR = 0; xL = 0;
    tempM = coe;
    m2matrix = M2matrix(N(ell), d, beta(ell));
    while exte(1) > Exterior_res(1, ell) * mu
        xR = xR + d;
        tempM = m2matrix * tempM;
        if abs(xR) >= Xmax
            break
        end
        exte(1) = Exterior_error_indicator(tempM, N(ell), beta(ell), 'R');
    end
    
    tempM = coe;
    m2matrix = M2matrix(N(ell), -d, beta(ell));
    while exte(2) > Exterior_res(2, ell) * mu
        xL = xL - d;
        tempM = m2matrix * tempM;
        if abs(xL) >= Xmax
            break
        end
        exte(2) = Exterior_error_indicator(tempM, N(ell), beta(ell),'L');
    end
    
    % moving update
    displace = xR + xL;
    m2matrix = M2matrix(N(ell), displace, beta(ell));
    coe = m2matrix * coe;

    exte = Exterior_error_indicator(coe, N(ell), beta(ell));
    Exterior_res(:, ell + 1) = exte;
    
    alpha(ell + 1) = alpha(ell) + displace;
    
    % scaling
    freq = Frequency_indicator(coe, N(ell))
    
    sx = 1;
    if freq(1) > Frequency_res(1, ell)/q
        s2matrix = S2matrix(N(ell), q);
        invs2matrix = S2matrix(N(ell), 1/q);
    
        tempsx = sx * q;
        tempS = s2matrix * coe;
        freq_update = Frequency_indicator(tempS, N(ell));
        if freq_update <= freq(1)
            while freq_update <= freq(1)
                freq(1) = freq_update;
                sx = tempsx;
                tempsx = tempsx * q;
                tempS = s2matrix * tempS;
                freq_update = Frequency_indicator(tempS, N(ell));
            end
        else
            tempsx = sx/q;
            tempS = invs2matrix * coe;
            freq_update = Frequency_indicator(tempS, N(ell));
            while freq_update <= freq(1)
                freq(1) = freq_update;
                sx = tempsx;
                tempsx = tempsx/q;
                tempS = invs2matrix * tempS;
                freq_update = Frequency_indicator(tempS, N(ell));
            end
        end
    end
    
    % scaling update
    Frequency_res(:, ell + 1) = freq;
    sx;
    s2matrix = S2matrix(N(ell), sx);
    coe = s2matrix * coe;
    
    beta(ell + 1) = beta(ell) .* sx;
    
    % p-adaptive
    if ell == 1
        P_res = freq;
    end
    pfreq = Frequency_indicator(coe, N(ell));
    dN = 0;
    flag = 0;
    while pfreq > P_res * eta && dN < Nmax
        flag = 1;
        dN = dN + 1;
        p2matrix = pn2matrix(N(ell), dN, alpha(:, ell + 1), beta(:, ell + 1));
        tempP = p2matrix * coe;
        pfreq = Frequency_indicator(tempP, N(ell) + dN);
    end
    if flag == 1
        eta = eta * eg;
        P_res = pfreq;
    end
    % order update
    N(ell + 1) = N(ell) + dN;
    N(ell + 1)
    p2matrix = pn2matrix(N(ell), dN, alpha(:, ell + 1), beta(:, ell + 1));
    coe = p2matrix * coe;
    
    freq = Frequency_indicator(coe, N(ell));
    exte = Exterior_error_indicator(coe, N(ell), beta(ell));

    exterior_recorder(:, ell) = exte;
    frequency_recorder(:, ell) = freq;
end
clearvars -except alpha beta N Error frequency_recorder exterior_recorder
rmpath(genpath('E1_utils_Chebyshev'))