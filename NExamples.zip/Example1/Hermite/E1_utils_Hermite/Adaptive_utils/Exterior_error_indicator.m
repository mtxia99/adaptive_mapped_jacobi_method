function exte = Exterior_error_indicator(coe, N, beta, direction)
    Iup = N + 1 - floor(N/3); Idown = floor(N/3);
    [col, ~] = Quad(N, 0, beta(1));
    if nargin == 3
        position = [col(Iup), col(Idown)];
        exte = [ExR(coe, N, beta, position(1));
                ExL(coe, N, beta, position(2))];
    elseif strcmp(direction, 'R')
        position = col(Iup);
        exte = ExR(coe, N, beta, position);
    elseif strcmp(direction, 'L')
        position = col(Idown);
        exte = ExL(coe, N, beta, position);
    end
end

function val = ExR(coe, N, beta, position)
    total = 0; res = 0;
    dmat = D2matrix(N, beta);
    smat = semiR(N, beta, position);
    for m = 1 : N
        for n = 1 : N
            total = total + coe(m) * coe(n) * dmat(m, n);
            res = res + coe(m) * coe(n) * smat(m, n);
        end
    end
    val = sqrt(res/total);
end

function val = ExL(coe, N, beta, position)
    total = 0; res = 0;
    dmat = D2matrix(N, beta);
    smat = semiL(N, beta, position);

    for m = 1 : N
        for n = 1 : N
            total = total + coe(m) * coe(n) * dmat(m, n);
            res = res + coe(m) * coe(n) * smat(m, n);
        end
    end
    val = sqrt(res/total);
end

function sdmat = semiR(N, beta, position)
    [col, w] = MCSG_semi_algebraic(N, position, 1);
    Dvec = zeros(N);
    for ell = 0 : N - 1
        Dvec(:, ell + 1) = D1Basis(col, ell, 0, beta);
    end
    sdmat = Dvec' * diag(w) * Dvec;
end

function sdmat = semiL(N, beta, position)
    [col, w] = MCSG_semi_algebraic(N, 0, 1);
    col = position - col;
    Dvec = zeros(N);
    for ell = 0 : N - 1
        Dvec(:, ell + 1) = D1Basis(col, ell, 0, beta);
    end
    sdmat = Dvec' * diag(w) * Dvec;
end

function val = Delta(m, n)
    if m == n
        val = 1;
    else
        val = 0;
    end
end

function [col, w] = MCSG_semi_algebraic(N, alpha, beta)
    temp = zeros(1, N);
    for m = 0 : N - 1
        temp(m + 1) = - cos((2*m + 1)*pi/(2*N));
    end
    col = 1/beta * (1 + temp)./(1 - temp);
    w = 2 * pi/N/beta ./(1 - temp).^2 .* sqrt(1 - temp.^2);
    col = col + alpha;
end