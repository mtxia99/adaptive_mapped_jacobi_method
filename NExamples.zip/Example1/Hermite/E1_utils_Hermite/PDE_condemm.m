clear

alpha = 0;
beta = 1;
N = 64;

% initialization
[col, w] = Quad(N, alpha, beta);
[Proj, Inv] = P1matrix(N, alpha, beta);
% Proj * Inv
u = Analytic(col, 0);
coe = Proj * u'
% Inv * coe - u'

d2matrix = D2matrix(N, beta);
Dproj = D1matrix(N, alpha, beta);
Dinv = D1inv(N, alpha, beta);
sinv = Sinv(N, alpha, beta);

coe = d2matrix * coe/2 + Nonlinear(coe, Dproj, Inv, sinv)


