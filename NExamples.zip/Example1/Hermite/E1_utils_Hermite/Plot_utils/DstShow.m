x = linspace(-8, 8, 1000);

% figure
% for ell = 1: 10: 150
%    plot(x, Inverse(x, Coe(:, ell + 1), alpha(ell), beta(ell)), 'Linewidth', 1 + 1.5 * ell/150, 'color', [0, 150 - ell, ell]/150)
%    hold on
% end
% plot(x, Analytic(x, 0), '--', 'Linewidth', 2, 'color', [0.75, 0.75, 0.75])
% % print('-dpdf','logdist')

% figure
yyaxis left
semilogy(0.1 : 0.1 : 3, frequency_recorder(1, 1:30), 'Linewidth', 3, 'color', [56, 104, 166]/255)
hold on
plot(0.1 : 0.3 : 3, frequency_recorder(1, 1 : 3 : 30), 'o', 'Linewidth', 2, 'Color', [56, 104, 166]/255)
ylim([1e-8, 1e-7])
yyaxis right
plot(0 : 0.1 : 3, beta, 'Linewidth', 3, 'color', [247, 209, 118]/255)
hold on
plot(0 : 0.3 : 3, beta(1 : 3 : 31), '<', 'Linewidth', 2, 'Color', [247, 209, 118]/255)
set(gca, 'yminortick', 'off')
print('-dpdf','scale')