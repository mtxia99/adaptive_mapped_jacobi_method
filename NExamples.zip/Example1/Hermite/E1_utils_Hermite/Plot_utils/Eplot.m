function Eplot(L)
    t = 0.1:0.1:3;
    mark = 1 : 3 : 30;
    figure
    semilogy(t, L(1, :), 'Linewidth', 3, 'Color', [56, 104, 166]/255)
    hold on
    semilogy(t, L(2, :), 'Linewidth', 3, 'Color', [247, 209, 118]/255)
%     semilogy(t, L(3, :), 'Linewidth', 3, 'Color', [188, 85, 101]/255)
    legend('nonadaptive', 'adaptive')
    semilogy(t(mark), L(1, mark), '<', 'Linewidth', 2, 'Color', [56, 104, 166]/255)
    semilogy(t(mark), L(2, mark), 'o', 'Linewidth', 2, 'Color', [247, 209, 118]/255)
%     semilogy(t(mark), L(3, mark), '>', 'Linewidth', 2, 'Color', [188, 85, 101]/255)
%     
    set(gca, 'yminortick', 'off')
end