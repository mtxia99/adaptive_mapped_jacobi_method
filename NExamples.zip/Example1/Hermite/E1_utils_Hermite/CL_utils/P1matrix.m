function [Proj, Inv] = P1matrix(N, alpha, beta)
    [col, w] = Quad(N, alpha, beta);
    Proj = zeros(N, N); Inv = zeros(N, N);
    for ell = 0 : N - 1
        B1vec = Basis(col, ell, alpha, beta);
        Proj(ell + 1, :) = B1vec .* w; Inv(:, ell + 1) = B1vec';
    end
end