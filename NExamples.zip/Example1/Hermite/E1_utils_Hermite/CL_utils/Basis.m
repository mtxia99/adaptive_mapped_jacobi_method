function val = Basis(x, N, alpha, beta)
    x = (x - alpha) * beta;
    if N < 0
        val = 0;
    elseif N == 0
        val = pi^(-1/4) * exp(-x.^2/2);
    elseif N == 1
        val = sqrt(2) * pi^(-1/4) * x .* exp(-x.^2/2);
    else
        v0 = pi^(-1/4) * exp(-x.^2/2);
        v1 = sqrt(2) * pi^(-1/4) * x .* exp(-x.^2/2);
        for n = 0 : N - 2
            v2 = sqrt(2/(n + 2)) * x .* v1 - sqrt((n + 1)/(n + 2)) * v0;
            v0 = v1;
            v1 = v2;
        end
        val = v2;
    end
    val = sqrt(beta) * val;
end