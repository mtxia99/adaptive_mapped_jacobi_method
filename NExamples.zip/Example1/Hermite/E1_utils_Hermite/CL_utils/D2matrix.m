function d2matrix = D2matrix(N, beta)
    D = DF1mat(N, beta); [V, E] = eig(D, 'vector');
    E = sqrt(E);
    d2matrix = V * diag(E) * V';
end

function A = DF1mat(N, beta)
    A = zeros(N);
    for m = 0 : N - 1
        for n = 0 : N - 1
            if m == n
                A(m + 1, n + 1) = beta^2/2 * (2 * m + 1);
            elseif m == n - 2
                A(m + 1, n + 1) = -beta^2/2 * sqrt((m + 1)*(m + 2));
            elseif m == n + 2
                A(m + 1, n + 1) = -beta^2/2 * sqrt(m*(m - 1));
            end
        end
    end
end