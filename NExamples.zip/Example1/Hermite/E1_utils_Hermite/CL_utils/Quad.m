function [col, w] = Quad(N, alpha, beta)
    A = zeros(N);
    for n = 0 : N - 1
        if n == 0
            A(n + 1, n + 1) = 0;
            A(n + 1, n + 2) = sqrt((n + 1)/2);
        elseif n == N - 1
            A(n + 1, n + 1) = 0;
            A(n + 1, n) = sqrt(n/2);
        else
            A(n + 1, n + 1) = 0;
            A(n + 1, n) = sqrt(n/2);
            A(n + 1, n + 2) = sqrt((n + 1)/2);
        end
    end
    col = eig(A);
    col = sort(col)';
    w = 1/beta/N./Basis(col, N - 1, 0, 1).^2;
    col = col/beta + alpha;
end