function val = D1Basis(x, N, alpha, beta)
    val = sqrt(N/2) * Basis(x, N - 1, alpha, beta) - sqrt((N + 1)/2) * Basis(x, N + 1, alpha, beta);
    val = beta * val;
end
