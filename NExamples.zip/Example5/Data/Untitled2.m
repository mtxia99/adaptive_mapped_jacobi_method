% spectral method parameters
alpha = zeros(4, KT);
beta = 1.05 * ones(4, KT);
N = 12 * ones(1, KT); gamma = 3;
[Nx, Ny, Nz, Nw] = Hyperbolic(N(1), gamma);

% initialization
[col_x, wx] = Quad(N(1), alpha(1, 1), beta(1, 1));
[col_y, wy] = Quad(N(1), alpha(2, 1), beta(2, 1));
[col_z, wz] = Quad(N(1), alpha(3, 1), beta(3, 1));
[col_w, ww] = Quad(N(1), alpha(4, 1), beta(4, 1));

[X, Y, Z, W] = ndgrid(col_x, col_y, col_z, col_w);
[wx, wy, wz, ww] = ndgrid(wx, wy, wz, ww); w = wx .* wy .* wz .* ww;
[Proj, Inv] = P2matrix(N(1), alpha(:, 1), beta(:, 1), Nx, Ny, Nz, Nw);

u = Analytic(X, Y, Z, W, 0);
uvec = Vec(u);
coe = Proj * uvec;

xu = XD(X, Y, Z, W, 0);
xuvec = Vec(xu);
xcoe = Proj * xuvec;

Xmat = XDmat(N(1), beta(:, 1), Nx, Ny, Nz, Nw);

sqrt(sum((xcoe - Xmat * coe).^2))