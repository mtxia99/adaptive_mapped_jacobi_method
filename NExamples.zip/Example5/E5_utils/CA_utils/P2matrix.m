function [Proj, Inv] = P2matrix(N, alpha, beta, Nx, Ny, Nz, Nw)
    [col_x, wx] = Quad(N, alpha(1), beta(1));
    [col_y, wy] = Quad(N, alpha(2), beta(2));
    [col_z, wz] = Quad(N, alpha(3), beta(3));
    [col_w, ww] = Quad(N, alpha(4), beta(4));
    
    [X, Y, Z, W] = ndgrid(col_x, col_y, col_z, col_w);
    [wx, wy, wz, ww] = ndgrid(wx, wy, wz, ww);
    w = wx .* wy .* wz .* ww;
    
    NC = length(Nx);
    Proj = zeros(NC, N^4); Inv = zeros(N^4, NC);
    for ell = 1 : NC
        nx = Nx(ell); ny = Ny(ell); nz = Nz(ell); nw = Nw(ell);
        B2vec = Basis(X, nx, alpha(1), beta(1)) .* Basis(Y, ny, alpha(2), beta(2)) .* Basis(Z, nz, alpha(3), beta(3)) .* Basis(W, nw, alpha(4), beta(4));
        
        P2vec = Vec(B2vec .* w); Proj(ell, :) = P2vec;
        
        I2vec = Vec(B2vec); Inv(:, ell) = I2vec';
    end
end