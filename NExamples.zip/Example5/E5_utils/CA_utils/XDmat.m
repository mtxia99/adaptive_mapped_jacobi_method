function d2matrix = XDmat(N, beta, Nx, Ny, Nz, Nw)
    NC = length(Nx);

    Dmat = DF1mat(N, 1);
    
    d2matrix = zeros(NC, NC);
    for n1 = 1 : NC
        for n2 = 1 : NC
            v1 = 0;
            v2 = 0;
            v3 = 0;
            v4 = 0;
            if Ny(n1) == Ny(n2) && Nz(n1) == Nz(n2) && Nw(n1) == Nw(n2)
                v1 = Dmat(Nx(n1) + 1, Nx(n2) + 1)/beta(1)^2;
            end
            if Nx(n1) == Nx(n2) && Nz(n1) == Nz(n2) && Nw(n1) == Nw(n2)
                v2 = Dmat(Ny(n1) + 1, Ny(n2) + 1)/beta(2)^2;
            end
            if Nx(n1) == Nx(n2) && Ny(n1) == Ny(n2) && Nw(n1) == Nw(n2)
                v3 = Dmat(Nz(n1) + 1, Nz(n2) + 1)/beta(3)^2;
            end
            if Nx(n1) == Nx(n2) && Ny(n1) == Ny(n2) && Nz(n1) == Nz(n2)
                v4 = Dmat(Nw(n1) + 1, Nw(n2) + 1)/beta(4)^2;
            end
            d2matrix(n1, n2) = v1 + v2 + v3 + v4;
        end
    end
end

function A = DF1mat(N, beta)
    A = zeros(N);
    for m = 0 : N - 1
        for n = 0 : N - 1
            if m == n
                A(m + 1, n + 1) = (2 * m + 1)/2/beta^2;
            elseif m == n - 2
                A(m + 1, n + 1) = sqrt((m + 1)*(m + 2))/2/beta^2;
            elseif m == n + 2
                A(m + 1, n + 1) = sqrt(m*(m - 1))/2/beta^2;
            end
        end
    end
end