function Fval = F(x, y, z, w, t)
    Fval = Dt(x, y, z, w, t) - FD(x, y, z, w, t) + XD(x, y, z, w, t);
end

function val = Dt(x, y, z, w, t)
    A = x.^2 + y.^2 + z.^2 + w.^2;
    val = cos((x + y + z + w)) .* exp(-A/(2*t + 2)) .* (A/2/(t + 1)^4 - 2/(t + 1)^3);
end

function val = FD(x, y, z, w, t)
    A = x.^2 + y.^2 + z.^2 + w.^2;
    B = (x + y + z + w);
    val = 2 * B .* sin(B)/(t + 1)^3 + cos(B) .* (A/(t + 1)^2 - 4/(t + 1))/(t + 1)^2 - 4 * cos(B)/(t + 1)^2;
    val = val .* exp(-A/2/(t + 1));
end

function val = XD(x, y, z, w, t)
    val = cos((x + y + z + w)) .* exp(-x.^2/(2*t + 2) - y.^2/(2*t + 2) - z.^2/(2*t + 2) - w.^2/(2*t + 2))/(t + 1)^2;
    val = val .* (x.^2 + y.^2 + z.^2 + w.^2);
end