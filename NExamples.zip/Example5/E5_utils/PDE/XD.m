function val = XD(x, y, z, w, t)
    val = cos((x + y + z + w)) .* exp(-x.^2/(2*t + 2) - y.^2/(2*t + 2) - z.^2/(2*t + 2) - w.^2/(2*t + 2))/(t + 1)^2;
    val = val .* (x.^2 + y.^2 + z.^2 + w.^2);
end