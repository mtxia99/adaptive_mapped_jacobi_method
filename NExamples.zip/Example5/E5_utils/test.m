clear;

% spatiotemporal parameters
T = 1; dt = 0.1;
time = 0 : dt : T;
KT = length(time);

% spectral method parameters
alpha = zeros(4, KT);
beta = 1 * ones(4, KT);
N = 10 * ones(1, KT); gamma = 1;
[Nx, Ny, Nz, Nw] = Hyperbolic(N(1), gamma);

% initialization
[col_x, wx] = Quad(N(1), alpha(1, 1), beta(1, 1));
[col_y, wy] = Quad(N(1), alpha(2, 1), beta(2, 1));
[col_z, wz] = Quad(N(1), alpha(3, 1), beta(3, 1));
[col_w, ww] = Quad(N(1), alpha(4, 1), beta(4, 1));

[X, Y, Z, W] = ndgrid(col_x, col_y, col_z, col_w);
[wx, wy, wz, ww] = ndgrid(wx, wy, wz, ww); w = wx .* wy .* wz .* ww;
[Proj, Inv] = P2matrix(N(1), alpha(:, 1), beta(:, 1), Nx, Ny, Nz, Nw);

u = Analytic(X, Y, Z, W, 0);
uvec = Vec(u);
coe = Proj * uvec;

% Recorders
Error = zeros(1, KT - 1);

% adaptive recorders
freq = Frequency_indicator(coe, N(1), gamma, Nx, Ny, Nz, Nw)
Frequency_res = freq * ones(1, KT);
frequency_recorder = Frequency_res;

uinv = Inverse(X, Y, Z, W, coe, alpha(:, 1), beta(:, 1), Nx, Ny, Nz, Nw);
ref = Analytic(X, Y, Z, W, 0);
error = sqrt(sum(sum(sum(sum((ref - uinv).^2 .* w)))))/sqrt(sum(sum(sum(sum((ref).^2 .* w)))))

ell = 1;
% adaptives
betamin = 0; q = 0.995;

for ell = 1 : KT - 1
    % initialize
    [col_x, wx] = Quad(N(ell), alpha(1, ell), beta(1, ell));
    [col_y, wy] = Quad(N(ell), alpha(2, ell), beta(2, ell));
    [col_z, wz] = Quad(N(ell), alpha(3, ell), beta(3, ell));
    [col_w, ww] = Quad(N(ell), alpha(4, ell), beta(4, ell));
    [X, Y, Z, W] = ndgrid(col_x, col_y, col_z, col_w);
    [wx, wy, wz, ww] = ndgrid(wx, wy, wz, ww); w = wx .* wy .* wz .* ww;
    [Proj, Inv] = P2matrix(N(ell), alpha(:, ell), beta(:, ell), Nx, Ny, Nz, Nw);
    d2matrix = D2matrix(N(ell), beta(:, ell), Nx, Ny, Nz, Nw);
    
    % RK method
    stage = time(ell) + dt * [0.069432, 0.33001, 0.66999, 0.93057];
    coe = RK_solver(coe, dt, d2matrix);
    
    % Record error
    uinv = Inverse(X, Y, Z, W, coe, alpha(:, ell), beta(:, ell), Nx, Ny, Nz, Nw);
    ref = Analytic(X, Y, Z, W, time(ell + 1));
    error = sqrt(sum(sum(sum(sum((ref - uinv).^2 .* w)))))/sqrt(sum(sum(sum(sum((ref).^2 .* w)))))
    Error(ell) = error;
    
%     % scaling
%     freq = Frequency_indicator(coe, N(ell), gamma, Nx, Ny, Nz, Nw);
%     
%     sx = 1;
%     if freq(1) > Frequency_res(1, ell)
%         s2matrix = S2matrix(N(ell), [q; 1; 1; 1], Nx, Ny, Nz, Nw);
%         tempsx = sx * q;
%         tempS = s2matrix * coe;
%         freq_update = Frequency_indicator(tempS, N(ell), gamma, Nx, Ny, Nz, Nw, 'x');
%         while freq_update <= freq(1)
%             freq(1) = freq_update;
%             sx = tempsx;
%             tempsx = tempsx * q;
%             tempS = s2matrix * tempS;
%             freq_update = Frequency_indicator(tempS, N(ell), gamma, Nx, Ny, Nz, Nw, 'x');
%         end
%     end
%     
%     sy = 1;
%     if freq(2) > Frequency_res(2, ell)
%         s2matrix = S2matrix(N(ell), [1; q; 1; 1], Nx, Ny, Nz, Nw);
%         tempsy = sy * q;
%         tempS = s2matrix * coe;
%         freq_update = Frequency_indicator(tempS, N(ell), gamma, Nx, Ny, Nz, Nw, 'y');
%         while freq_update <= freq(2)
%             freq(2) = freq_update;
%             sy = tempsy;
%             tempsy = tempsy * q;
%             tempS = s2matrix * tempS;
%             freq_update = Frequency_indicator(tempS, N(ell), gamma, Nx, Ny, Nz, Nw, 'y');
%         end
%     end
%     
%     sz = 1;
%     if freq(3) > Frequency_res(3, ell)
%         s2matrix = S2matrix(N(ell), [1; 1; q; 1], Nx, Ny, Nz, Nw);
%         tempsz = sz * q;
%         tempS = s2matrix * coe;
%         freq_update = Frequency_indicator(tempS, N(ell), gamma, Nx, Ny, Nz, Nw, 'z');
%         while freq_update <= freq(3)
%             freq(3) = freq_update;
%             sz = tempsz;
%             tempsz = tempsz * q;
%             tempS = s2matrix * tempS;
%             freq_update = Frequency_indicator(tempS, N(ell), gamma, Nx, Ny, Nz, Nw, 'z');
%         end
%     end
%     
%     sw = 1;
%     if freq(4) > Frequency_res(4, ell)
%         s2matrix = S2matrix(N(ell), [1; 1; 1; q], Nx, Ny, Nz, Nw);
%         tempsw = sw * q;
%         tempS = s2matrix * coe;
%         freq_update = Frequency_indicator(tempS, N(ell), gamma, Nx, Ny, Nz, Nw, 'w');
%         while freq_update <= freq(4)
%             freq(4) = freq_update;
%             sw = tempsw;
%             tempsw = tempsw * q;
%             tempS = s2matrix * tempS;
%             freq_update = Frequency_indicator(tempS, N(ell), gamma, Nx, Ny, Nz, Nw, 'w');
%         end
%     end
%     
%     % scaling update
%     Frequency_res(:, ell + 1) = freq;
%     factor = [sx; sy; sz; sw]
%     s2matrix = S2matrix(N(ell), factor, Nx, Ny, Nz, Nw);
%     coe = s2matrix * coe;
%     
%     beta(:, ell + 1) = beta(:, ell) .* factor; 
%     
%     freq = Frequency_indicator(coe, N(ell + 1), gamma, Nx, Ny, Nz, Nw);
%     frequency_recorder(:, ell) = freq;
end