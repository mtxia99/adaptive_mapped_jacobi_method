function [Nx, Ny, Nz, Nw] = Hyperbolic(N, gamma)
    [X, Y, Z, W] = ndgrid(0:N-1, 0:N-1, 0:N-1, 0:N-1);
    Nx = zeros(1, N^4); Ny = zeros(1, N^4);
    Nz = zeros(1, N^4); Nw = zeros(1, N^4);
    
    rec = 0;
    for ell = 1 : N
        for nu = 1 : N
            for bm = 1 : N
                for it = 1 : N
                    if max(1, X(ell, nu, bm, it)) * max(1, Y(ell, nu, bm, it)) * max(1, Z(ell, nu, bm, it)) * max(1, W(ell, nu, bm, it)) * max(X(ell, nu, bm, it), max(Y(ell, nu, bm, it), max(Z(ell, nu, bm, it), W(ell, nu, bm, it))))^gamma <= N^(1 + gamma)
                        rec = rec + 1;
                        Nx(rec) = ell - 1;
                        Ny(rec) = nu - 1;
                        Nz(rec) = bm - 1;
                        Nw(rec) = it - 1;
                    end
                end
            end
        end
    end
    Nx = Nx(1 : rec); Ny = Ny(1 : rec); Nz = Nz(1 : rec); Nw = Nw(1 : rec);
end