function v = Vec(u)
    [M, N, B, L] = size(u);
    v = zeros(M * N * B * L, 1);
    for ell = 1 : M
        for nu = 1 : N
            for bm = 1 : B
                for it = 1 : L
                    v(ell + M * (nu - 1) + M * N * (bm - 1) + M * N * B * (it - 1)) = u(ell, nu, bm, it);
                end
            end
        end
    end
end