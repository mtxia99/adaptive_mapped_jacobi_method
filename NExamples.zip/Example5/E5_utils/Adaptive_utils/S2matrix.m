function s2matrix = S2matrix(N, q, Nx, Ny, Nz, Nw)
    [col_x, wx] = Quad(N, 0, q(1));
    [col_y, wy] = Quad(N, 0, q(2));
    [col_z, wz] = Quad(N, 0, q(3));
    [col_w, ww] = Quad(N, 0, q(4));
    
    [X, Y, Z, W] = ndgrid(col_x, col_y, col_z, col_w);
    [wx, wy, wz, ww] = ndgrid(wx, wy, wz, ww);
    w = wx .* wy .* wz .* ww;
    
    NC = length(Nx);
    Proj = zeros(NC, N^4); Inv = zeros(N^4, NC);
    for ell = 1 : NC
        nx = Nx(ell); ny = Ny(ell); nz = Nz(ell); nw = Nw(ell);
        B2vec = Basis(X, nx, 0, q(1)) .* Basis(Y, ny, 0, q(2)) .* Basis(Z, nz, 0, q(3)) .* Basis(W, nw, 0, q(4));
        P2vec = Vec(B2vec .* w); Proj(ell, :) = P2vec;
        
        B2vec = Basis(X, nx, 0, 1) .* Basis(Y, ny, 0, 1) .* Basis(Z, nz, 0, 1) .* Basis(W, nw, 0, 1);
        I2vec = Vec(B2vec); Inv(:, ell) = I2vec';
    end
    s2matrix = Proj * Inv;
end