function freq = Frequency_indicator_compare(coe, N, gamma, Nx, Ny, Nz, Nw, direction)
    if nargin == 7
        freq = [Fx(coe, N, gamma, Nx, Ny, Nz, Nw);
                Fy(coe, N, gamma, Nx, Ny, Nz, Nw);
                Fz(coe, N, gamma, Nx, Ny, Nz, Nw)
                Fw(coe, N, gamma, Nx, Ny, Nz, Nw)];
    elseif strcmp(direction, 'y')
        freq = Fy(coe, N, gamma, Nx, Ny, Nz, Nw);
    elseif strcmp(direction, 'w')
        freq = Fw(coe, N, gamma, Nx, Ny, Nz, Nw);
    elseif strcmp(direction, 'x')
        freq = Fx(coe, N, gamma, Nx, Ny, Nz, Nw);
    elseif strcmp(direction, 'z')
        freq = Fz(coe, N, gamma, Nx, Ny, Nz, Nw);
    end
end

function fx = Fx(coe, N, gamma, Nx, Ny, Nz, Nw)
    total = sum(coe.^2); res = 0;
    NC = length(Nx);
    for n = 1 : NC
        if Nx(n) > floor((2 * N + 2)/3)
            res = res + coe(n)^2;
        end
    end
    fx = sqrt(res/total);
end

function fy = Fy(coe, N, gamma, Nx, Ny, Nz, Nw)
    total = sum(coe.^2); res = 0;
    NC = length(Ny);
    for n = 1 : NC
        if Ny(n) > floor((2 * N + 2)/3)
            res = res + coe(n)^2;
        end
    end
    fy = sqrt(res/total);
end

function fz = Fz(coe, N, gamma, Nx, Ny, Nz, Nw)
    total = sum(coe.^2); res = 0;
    NC = length(Nz);
    for n = 1 : NC
        if Nz(n) > floor((2 * N + 2)/3)
            res = res + coe(n)^2;
        end
    end
    fz = sqrt(res/total);
end

function fw = Fw(coe, N, gamma, Nx, Ny, Nz, Nw)
    total = sum(coe.^2); res = 0;
    NC = length(Nw);
    for n = 1 : NC
        if Nw(n) > floor((2 * N + 2)/3)
            res = res + coe(n)^2;
        end
    end
    fw = sqrt(res/total);
end