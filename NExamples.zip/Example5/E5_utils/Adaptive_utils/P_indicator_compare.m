function freq = P_indicator_compare(coe, N, gamma, Nx, Ny, Nz, Nw)
    fx = Fx(coe, N, gamma, Nx, Ny, Nz, Nw); fy = Fy(coe, N, gamma, Nx, Ny, Nz, Nw);
    fz = Fz(coe, N, gamma, Nx, Ny, Nz, Nw); fw = Fw(coe, N, gamma, Nx, Ny, Nz, Nw);
    freq = sqrt(fx^2 + fy^2 + fz^2 + fw^2);
end

function fx = Fx(coe, N, gamma, Nx, Ny, Nz, Nw)
    total = sum(coe.^2); res = 0;
    NC = length(Nx);
    for n = 1 : NC
        if Nx(n) > floor((2 * N + 2)/3)
            res = res + coe(n)^2;
        end
    end
    fx = sqrt(res/total);
end

function fy = Fy(coe, N, gamma, Nx, Ny, Nz, Nw)
    total = sum(coe.^2); res = 0;
    NC = length(Ny);
    for n = 1 : NC
        if Ny(n) > floor((2 * N + 2)/3)
            res = res + coe(n)^2;
        end
    end
    fy = sqrt(res/total);
end

function fz = Fz(coe, N, gamma, Nx, Ny, Nz, Nw)
    total = sum(coe.^2); res = 0;
    NC = length(Nz);
    for n = 1 : NC
        if Nz(n) > floor((2 * N + 2)/3)
            res = res + coe(n)^2;
        end
    end
    fz = sqrt(res/total);
end

function fw = Fw(coe, N, gamma, Nx, Ny, Nz, Nw)
    total = sum(coe.^2); res = 0;
    NC = length(Nw);
    for n = 1 : NC
        if Nw(n) > floor((2 * N + 2)/3)
            res = res + coe(n)^2;
        end
    end
    fw = sqrt(res/total);
end