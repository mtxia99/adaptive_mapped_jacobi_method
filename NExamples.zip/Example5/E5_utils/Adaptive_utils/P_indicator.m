function freq = P_indicator(coe, N, gamma, Nx, Ny, Nz, Nw)
    total = sum(coe.^2); res = 0;
    NC = length(Nx);
    for n = 1 : NC
        if max(1, Nx(n)) * max(1, Ny(n)) * max(1, Nz(n)) * max(1, Nw(n)) * max(max(max(Nw(n), Nx(n)), Ny(n)), Nz(n))^gamma > (2/3 * N)^(1 + gamma)
            res = res + coe(n)^2;
        end
    end
    freq = sqrt(res/total);
end